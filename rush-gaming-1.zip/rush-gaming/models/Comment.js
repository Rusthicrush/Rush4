import mongoose from 'mongoose';

const CommentSchema = new mongoose.Schema({
  commenterName: { type: String, required: true, trim: true },
  commenterEmail: { type: String, required: true, lowercase: true },
  provider: { type: String, enum: ['google', 'facebook'], required: true },
  comment: { type: String, required: true, trim: true, maxlength: 1000 },
  pageName: { type: String, required: true, trim: true },
  pageSlug: { type: String, required: true, lowercase: true },
  approved: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.models.Comment || mongoose.model('Comment', CommentSchema);
