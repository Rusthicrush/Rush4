import mongoose from 'mongoose';

const ScoreSchema = new mongoose.Schema({
  playerName: { type: String, required: true, trim: true },
  playerEmail: { type: String, required: false },
  gameSlug: { type: String, required: true, lowercase: true },
  gameName: { type: String, required: true },
  score: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now },
});

ScoreSchema.index({ gameSlug: 1, score: -1 });

export default mongoose.models.Score || mongoose.model('Score', ScoreSchema);
