// models/News.js
import mongoose from 'mongoose';

const NewsSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 200 },
  slug: { type: String, required: true, unique: true, lowercase: true },
  excerpt: { type: String, required: true, maxlength: 500 },
  content: { type: String, required: true },
  imageUrl: { type: String, default: '' },
  category: { type: String, enum: ['Gaming', 'Esports', 'Updates', 'Reviews', 'Community'], default: 'Gaming' },
  tags: [{ type: String }],
  author: { type: String, default: 'RUSH Admin' },
  published: { type: Boolean, default: true },
  views: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

export default mongoose.models.News || mongoose.model('News', NewsSchema);
