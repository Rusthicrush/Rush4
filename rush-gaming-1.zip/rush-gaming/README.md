# ⚡ RUSH GAMING — Premium Galaxy Gaming Platform

> Built for Champions. Designed for the Future.

A full-stack Next.js gaming portal with 10 browser games, real-time leaderboards, admin news system, 5 themes, and a futuristic galaxy UI.

---

## 🎮 Games Included
- Space Battle (Shooter)
- Snake Game (Arcade)
- Car Racing (Racing)
- Chess (Strategy)
- Puzzle Blast / Match-3 (Puzzle)
- Memory Cards (Puzzle)
- Tic Tac Toe (Strategy)
- Block Puzzle (Puzzle)
- Galaxy Runner (Arcade)
- Shooting Range (Shooter)

## ✨ Features
- Galaxy Blue theme + 4 extra themes (Neon Dark, Cyber Purple, Ice Blue, Red Inferno)
- Admin dashboard (Rusthir236@gmail.com only)
- Comment system with Google/Facebook login
- Email notifications via Nodemailer
- MongoDB database
- NextAuth authentication
- Leaderboard system
- Animated particle galaxy background
- Glassmorphism cards, neon borders, scanline overlay

---

## 🚀 Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Setup environment variables
```bash
cp .env.example .env.local
```
Fill in all values in `.env.local`.

### 3. Run development server
```bash
npm run dev
```
Open http://localhost:3000

### 4. Build for production
```bash
npm run build
npm start
```

---

## 🔑 Environment Variables

| Variable | Description |
|----------|-------------|
| `NEXTAUTH_URL` | Your app URL |
| `NEXTAUTH_SECRET` | Random secret string |
| `MONGODB_URI` | MongoDB connection string |
| `GOOGLE_CLIENT_ID` | Google OAuth Client ID |
| `GOOGLE_CLIENT_SECRET` | Google OAuth Client Secret |
| `FACEBOOK_CLIENT_ID` | Facebook App ID |
| `FACEBOOK_CLIENT_SECRET` | Facebook App Secret |
| `EMAIL_HOST` | SMTP host (e.g. smtp.gmail.com) |
| `EMAIL_PORT` | SMTP port (587) |
| `EMAIL_USER` | Your email address |
| `EMAIL_PASS` | App password |
| `ADMIN_EMAIL_ADDRESS` | Rusthir236@gmail.com |

---

## 📁 Project Structure

```
/rush-gaming
├── components/
│   ├── Layout.js
│   ├── Navbar.js
│   ├── Footer.js
│   ├── ParticleBackground.js
│   ├── ThemeSwitcher.js
│   └── CommentsSection.js
├── pages/
│   ├── index.js           # Homepage
│   ├── leaderboard.js
│   ├── 404.js
│   ├── admin/index.js     # Admin dashboard
│   ├── auth/signin.js
│   ├── games/
│   │   ├── index.js       # Games list
│   │   └── [id].js        # Individual game (all 10 games here)
│   ├── news/
│   │   ├── index.js
│   │   └── [slug].js
│   └── api/
│       ├── auth/[...nextauth].js
│       ├── comments/index.js
│       ├── news/index.js
│       ├── news/[id].js
│       └── games/scores.js
├── models/
│   ├── News.js
│   ├── Comment.js
│   └── Score.js
├── lib/
│   ├── mongodb.js
│   └── email.js
├── styles/
│   └── globals.css
├── .env.example
├── next.config.js
├── tailwind.config.js
└── package.json
```

---

## 🌐 Deploy to Vercel

1. Push this repo to GitHub
2. Go to https://vercel.com → Import project
3. Add all environment variables from `.env.example`
4. Deploy!

---

## 🔒 Security
- Admin routes protected by email check
- Comments rate-limited (3 per minute per IP)
- HTML sanitized before saving
- Secrets in environment variables only
- NextAuth handles secure sessions

---

## 📧 Admin Access
Only `Rusthir236@gmail.com` can access `/admin`.
