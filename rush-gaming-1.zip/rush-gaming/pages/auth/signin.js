import { signIn } from 'next-auth/react';
import { useRouter } from 'next/router';
import Layout from '../../components/Layout';

export default function SignIn() {
  const router = useRouter();
  const { callbackUrl } = router.query;

  return (
    <Layout title="Sign In">
      <div style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 20px', position: 'relative', zIndex: 1 }}>
        <div className="glass-card corner-accent" style={{ width: '100%', maxWidth: '420px', padding: '48px' }}>
          {/* Logo */}
          <div style={{ textAlign: 'center', marginBottom: '40px' }}>
            <h1 style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900, fontSize: '3rem', color: 'var(--accent-primary)', textShadow: '0 0 20px var(--accent-primary)', marginBottom: '8px' }}>
              RUSH
            </h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', letterSpacing: '0.15em', fontFamily: 'Orbitron, monospace' }}>GAMING PORTAL</p>
          </div>

          <h2 style={{ fontFamily: 'Orbitron, monospace', fontSize: '1rem', color: 'var(--text-primary)', letterSpacing: '0.15em', marginBottom: '8px', textAlign: 'center' }}>
            SIGN IN
          </h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', textAlign: 'center', marginBottom: '32px', lineHeight: 1.5 }}>
            Sign in to post comments. No login needed to play games.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <button
              onClick={() => signIn('google', { callbackUrl: callbackUrl || '/' })}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px',
                padding: '14px 24px',
                background: 'rgba(234, 67, 53, 0.1)',
                border: '1px solid rgba(234, 67, 53, 0.4)',
                borderRadius: '8px',
                color: '#fff',
                fontFamily: 'Exo 2, sans-serif',
                fontSize: '0.95rem',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.3s',
                width: '100%',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = 'rgba(234, 67, 53, 0.2)'; e.currentTarget.style.boxShadow = '0 0 20px rgba(234, 67, 53, 0.3)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'rgba(234, 67, 53, 0.1)'; e.currentTarget.style.boxShadow = 'none'; }}
            >
              <span style={{ fontSize: '1.2rem' }}>🔴</span>
              Continue with Google
            </button>

            <button
              onClick={() => signIn('facebook', { callbackUrl: callbackUrl || '/' })}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px',
                padding: '14px 24px',
                background: 'rgba(24, 119, 242, 0.1)',
                border: '1px solid rgba(24, 119, 242, 0.4)',
                borderRadius: '8px',
                color: '#fff',
                fontFamily: 'Exo 2, sans-serif',
                fontSize: '0.95rem',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.3s',
                width: '100%',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = 'rgba(24, 119, 242, 0.2)'; e.currentTarget.style.boxShadow = '0 0 20px rgba(24, 119, 242, 0.3)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'rgba(24, 119, 242, 0.1)'; e.currentTarget.style.boxShadow = 'none'; }}
            >
              <span style={{ fontSize: '1.2rem' }}>🔵</span>
              Continue with Facebook
            </button>
          </div>

          <p style={{ color: 'var(--text-secondary)', fontSize: '0.75rem', textAlign: 'center', marginTop: '24px', lineHeight: 1.5 }}>
            By signing in, you agree to our terms. Your login provider name will be displayed with your comments.
          </p>
        </div>
      </div>
    </Layout>
  );
}
