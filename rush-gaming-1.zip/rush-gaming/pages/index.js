import { useState, useEffect } from 'react';
import Link from 'next/link';
import Layout from '../components/Layout';
import ThemeSwitcher from '../components/ThemeSwitcher';

const FEATURED_GAMES = [
  { id: 'space-battle', name: 'Space Battle', desc: 'Defend the galaxy from alien invasion', emoji: '🚀', badge: 'hot', category: 'Shooter' },
  { id: 'snake-game', name: 'Snake Game', desc: 'Classic snake with galaxy twist', emoji: '🐍', badge: 'trending', category: 'Arcade' },
  { id: 'car-racing', name: 'Car Racing', desc: 'High-speed neon highway racing', emoji: '🏎️', badge: 'new', category: 'Racing' },
  { id: 'chess', name: 'Chess', desc: 'Strategic galaxy chess battle', emoji: '♟️', badge: null, category: 'Strategy' },
  { id: 'puzzle-blast', name: 'Puzzle Blast', desc: 'Match gems to blast your way up', emoji: '💎', badge: 'hot', category: 'Puzzle' },
  { id: 'memory-cards', name: 'Memory Cards', desc: 'Test your galactic memory', emoji: '🃏', badge: null, category: 'Puzzle' },
];

const MOCK_NEWS = [
  { id: 1, title: 'RUSH Platform Launch: The Future of Gaming is Here', excerpt: 'Welcome to RUSH — the most advanced gaming platform in the galaxy.', category: 'Community', date: '2025-01-15', emoji: '🚀' },
  { id: 2, title: 'New Space Battle Update: 3 New Weapons Added', excerpt: 'The latest Space Battle update brings devastating new weapons to the arsenal.', category: 'Updates', date: '2025-01-14', emoji: '⚡' },
  { id: 3, title: 'RUSH Leaderboard Season 1 Results Are In', excerpt: 'Season 1 has ended and the champions have been crowned.', category: 'Esports', date: '2025-01-13', emoji: '🏆' },
];

const MOCK_LEADERBOARD = [
  { rank: 1, name: 'NebulaDragon', score: 99420, game: 'Space Battle' },
  { rank: 2, name: 'StarViper', score: 87650, game: 'Car Racing' },
  { rank: 3, name: 'CyberGhost', score: 76310, game: 'Snake' },
  { rank: 4, name: 'CosmicRay', score: 64200, game: 'Space Battle' },
  { rank: 5, name: 'VoidWalker', score: 58900, game: 'Puzzle Blast' },
];

export default function Home() {
  const [news, setNews] = useState(MOCK_NEWS);
  const [leaderboard, setLeaderboard] = useState(MOCK_LEADERBOARD);
  const [comments, setComments] = useState([]);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [newsRes, scoresRes, commentsRes] = await Promise.all([
        fetch('/api/news?limit=3'),
        fetch('/api/games/scores?limit=5'),
        fetch('/api/comments?limit=4'),
      ]);
      const newsData = await newsRes.json();
      const scoresData = await scoresRes.json();
      const commentsData = await commentsRes.json();

      if (newsData.news?.length) setNews(newsData.news);
      if (scoresData.scores?.length) {
        setLeaderboard(scoresData.scores.map((s, i) => ({
          rank: i + 1, name: s.playerName, score: s.score, game: s.gameName
        })));
      }
      if (commentsData.comments?.length) setComments(commentsData.comments);
    } catch (e) { /* use mock data */ }
  };

  return (
    <Layout title="RUSH - Galaxy Gaming Platform" description="Your ultimate galaxy gaming destination">
      {/* HERO */}
      <section style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden', paddingTop: '40px' }}>
        {/* Radial glow bg */}
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 50%, rgba(0,80,200,0.15) 0%, transparent 70%)', zIndex: 0 }} />

        <div style={{ textAlign: 'center', position: 'relative', zIndex: 1, padding: '40px 20px' }}>
          {/* RUSH title */}
          <div className={`fade-in-up ${visible ? '' : 'opacity-0'}`}>
            <div style={{ position: 'relative', display: 'inline-block' }}>
              <h1 className="hero-rush-text">RUSH</h1>
              {/* Reflection */}
              <h1 className="hero-rush-text" style={{
                position: 'absolute', bottom: '-40%', left: 0, right: 0,
                transform: 'scaleY(-0.3)',
                opacity: 0.2,
                filter: 'blur(4px)',
                mask: 'linear-gradient(to bottom, black, transparent)',
                WebkitMask: 'linear-gradient(to bottom, black, transparent)',
              }}>RUSH</h1>
            </div>
          </div>

          <div className={`fade-in-up delay-2 ${visible ? '' : 'opacity-0'}`} style={{ marginTop: '16px' }}>
            <p style={{
              fontFamily: 'Orbitron, monospace',
              fontSize: 'clamp(0.9rem, 2.5vw, 1.3rem)',
              letterSpacing: '0.3em',
              color: 'var(--text-secondary)',
              textTransform: 'uppercase',
            }}>
              ENTER THE GALAXY · DOMINATE THE LEADERBOARD
            </p>
          </div>

          <div className={`fade-in-up delay-3 ${visible ? '' : 'opacity-0'}`} style={{ marginTop: '12px' }}>
            <p style={{
              color: 'var(--text-secondary)',
              fontSize: '1.1rem',
              maxWidth: '500px',
              margin: '0 auto',
              lineHeight: 1.6,
              opacity: 0.7,
            }}>
              10 premium browser games. Real-time leaderboards. Daily gaming news.
            </p>
          </div>

          <div className={`fade-in-up delay-4 ${visible ? '' : 'opacity-0'}`} style={{ display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap', marginTop: '36px' }}>
            <Link href="/games" className="neon-btn-solid" style={{ textDecoration: 'none', padding: '16px 40px', fontSize: '0.85rem' }}>
              ⚡ Play Now
            </Link>
            <Link href="/news" className="neon-btn" style={{ textDecoration: 'none', padding: '16px 40px', fontSize: '0.85rem' }}>
              📡 Latest News
            </Link>
          </div>

          {/* Stats */}
          <div className={`fade-in-up delay-5 ${visible ? '' : 'opacity-0'}`} style={{ display: 'flex', gap: '40px', justifyContent: 'center', flexWrap: 'wrap', marginTop: '60px' }}>
            {[{ val: '10', label: 'Games' }, { val: '∞', label: 'Players' }, { val: '24/7', label: 'Live' }, { val: '5', label: 'Themes' }].map(s => (
              <div key={s.label} style={{ textAlign: 'center' }}>
                <p style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900, fontSize: '2rem', color: 'var(--accent-primary)', textShadow: '0 0 20px var(--accent-primary)' }}>{s.val}</p>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.75rem', letterSpacing: '0.2em', textTransform: 'uppercase', fontFamily: 'Orbitron, monospace' }}>{s.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{ position: 'absolute', bottom: '30px', left: '50%', transform: 'translateX(-50%)', animation: 'float 2s ease-in-out infinite' }}>
          <div style={{ width: '24px', height: '40px', border: '2px solid var(--border-color)', borderRadius: '12px', display: 'flex', justifyContent: 'center', paddingTop: '6px' }}>
            <div style={{ width: '4px', height: '8px', background: 'var(--accent-primary)', borderRadius: '2px', animation: 'slideDown 1.5s ease-in-out infinite' }} />
          </div>
        </div>
      </section>

      {/* FEATURED GAMES */}
      <section style={{ padding: '80px 0', position: 'relative', zIndex: 1 }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '40px', flexWrap: 'wrap', gap: '16px' }}>
            <h2 className="section-header">Featured Games</h2>
            <Link href="/games" style={{ color: 'var(--accent-primary)', fontSize: '0.85rem', textDecoration: 'none', fontFamily: 'Orbitron, monospace', letterSpacing: '0.1em' }}>
              View All →
            </Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '24px' }}>
            {FEATURED_GAMES.map((game, i) => (
              <Link key={game.id} href={`/games/${game.id}`} style={{ textDecoration: 'none' }}>
                <div className={`game-card fade-in-up delay-${Math.min(i + 1, 5)}`} style={{ padding: '28px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                    <span style={{ fontSize: '3rem' }}>{game.emoji}</span>
                    {game.badge && <span className={`badge badge-${game.badge}`}>{game.badge}</span>}
                  </div>
                  <h3 style={{ fontFamily: 'Orbitron, monospace', fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '8px', letterSpacing: '0.05em' }}>{game.name}</h3>
                  <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', lineHeight: 1.5, marginBottom: '16px' }}>{game.desc}</p>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: '0.7rem', color: 'var(--accent-primary)', background: 'rgba(0,212,255,0.1)', border: '1px solid var(--border-color)', padding: '3px 10px', borderRadius: '100px', fontFamily: 'Orbitron, monospace' }}>{game.category}</span>
                    <span style={{ color: 'var(--accent-primary)', fontSize: '0.8rem', fontFamily: 'Orbitron, monospace' }}>PLAY →</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* NEWS + LEADERBOARD + COMMENTS (3 columns) */}
      <section style={{ padding: '40px 0 80px', position: 'relative', zIndex: 1 }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '40px' }}>

            {/* News */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '24px' }}>
                <h2 className="section-header">Latest News</h2>
                <Link href="/news" style={{ color: 'var(--accent-primary)', fontSize: '0.8rem', textDecoration: 'none', fontFamily: 'Orbitron, monospace' }}>All →</Link>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {news.map(n => (
                  <Link key={n.id || n._id} href={`/news/${n.slug || n.id}`} style={{ textDecoration: 'none' }}>
                    <div className="news-card" style={{ padding: '20px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                        <span style={{ fontSize: '1.5rem' }}>{n.emoji || '📰'}</span>
                        <span style={{ fontSize: '0.7rem', color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', letterSpacing: '0.1em' }}>{n.category}</span>
                      </div>
                      <h3 style={{ color: 'var(--text-primary)', fontWeight: 600, fontSize: '0.95rem', marginBottom: '8px', lineHeight: 1.4 }}>{n.title}</h3>
                      <p style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', lineHeight: 1.5 }}>{n.excerpt?.substring(0, 100)}...</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Leaderboard */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '24px' }}>
                <h2 className="section-header">Top Players</h2>
                <Link href="/leaderboard" style={{ color: 'var(--accent-primary)', fontSize: '0.8rem', textDecoration: 'none', fontFamily: 'Orbitron, monospace' }}>Full →</Link>
              </div>
              <div>
                {leaderboard.map(p => (
                  <div key={p.rank} className="leaderboard-row">
                    <span className={`rank-badge rank-${p.rank <= 3 ? p.rank : 'other'}`}>{p.rank}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ color: 'var(--text-primary)', fontWeight: 600, fontSize: '0.9rem', fontFamily: 'Orbitron, monospace', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</p>
                      <p style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>{p.game}</p>
                    </div>
                    <span style={{ color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', fontWeight: 700, fontSize: '0.9rem', textShadow: '0 0 10px var(--accent-primary)' }}>
                      {p.score?.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Comments */}
            <div>
              <h2 className="section-header" style={{ marginBottom: '24px' }}>Recent Comments</h2>
              {comments.length === 0 ? (
                <div className="glass-card" style={{ padding: '30px', textAlign: 'center' }}>
                  <p style={{ fontSize: '2rem', marginBottom: '8px' }}>💬</p>
                  <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>No comments yet. Play a game and share your thoughts!</p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {comments.map(c => (
                    <div key={c._id} className="glass-card" style={{ padding: '16px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                        <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.75rem', fontWeight: 700, color: 'var(--bg-primary)', fontFamily: 'Orbitron, monospace', flexShrink: 0 }}>
                          {c.commenterName?.charAt(0).toUpperCase()}
                        </div>
                        <div style={{ minWidth: 0 }}>
                          <p style={{ color: 'var(--text-primary)', fontWeight: 600, fontSize: '0.85rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.commenterName}</p>
                          <p style={{ color: 'var(--text-secondary)', fontSize: '0.7rem' }}>on {c.pageName}</p>
                        </div>
                      </div>
                      <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', lineHeight: 1.5 }}>{c.comment.substring(0, 120)}{c.comment.length > 120 ? '...' : ''}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        </div>
      </section>

      {/* THEME SHOWCASE */}
      <section style={{ padding: '60px 0', background: 'rgba(0, 5, 20, 0.5)', borderTop: '1px solid var(--border-color)', borderBottom: '1px solid var(--border-color)', position: 'relative', zIndex: 1 }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" style={{ textAlign: 'center' }}>
          <h2 className="section-header" style={{ marginBottom: '16px' }}>Customize Your Experience</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '32px', maxWidth: '500px', margin: '0 auto 32px' }}>
            5 premium themes to match your style. Switch anytime.
          </p>
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <ThemeSwitcher expanded={true} />
          </div>
        </div>
      </section>
    </Layout>
  );
}
