import { useState, useEffect } from 'react';
import Layout from '../components/Layout';

const GAMES = ['All', 'Space Battle', 'Snake Game', 'Car Racing', 'Puzzle Blast', 'Memory Cards', 'Shooting Range', 'Galaxy Runner'];

const MOCK = Array.from({ length: 20 }, (_, i) => ({
  _id: String(i),
  playerName: ['NebulaDragon','StarViper','CyberGhost','CosmicRay','VoidWalker','GalaxyKnight','PixelPilot','QuantumByte','NovaStrike','DarkMatter'][i % 10] + (i > 9 ? '_X' : ''),
  score: Math.floor(100000 - i * 4200 + Math.random() * 2000),
  gameName: GAMES[1 + (i % 7)],
  createdAt: new Date(Date.now() - i * 3600000).toISOString(),
}));

export default function Leaderboard() {
  const [scores, setScores] = useState(MOCK);
  const [game, setGame] = useState('All');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const params = game !== 'All' ? `?gameSlug=${encodeURIComponent(game.toLowerCase().replace(/\s+/g,'-'))}&limit=30` : '?limit=30';
    fetch(`/api/games/scores${params}`)
      .then(r => r.json())
      .then(d => { if (d.scores?.length) setScores(d.scores); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [game]);

  const filtered = game === 'All' ? scores : scores.filter(s => s.gameName === game);

  return (
    <Layout title="Leaderboard" description="RUSH Gaming global leaderboard">
      <div style={{ padding: '60px 0 80px', position: 'relative', zIndex: 1 }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div style={{ textAlign: 'center', marginBottom: '50px' }}>
            <h1 className="section-header" style={{ fontSize: '2.5rem', marginBottom: '12px' }}>Leaderboard</h1>
            <p style={{ color: 'var(--text-secondary)' }}>Top players across the galaxy</p>
          </div>

          {/* Game Filter */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '40px', justifyContent: 'center' }}>
            {GAMES.map(g => (
              <button key={g} onClick={() => setGame(g)} style={{
                padding: '8px 16px',
                fontFamily: 'Orbitron, monospace', fontSize: '0.68rem', letterSpacing: '0.08em',
                border: `1px solid ${game === g ? 'var(--accent-primary)' : 'var(--border-color)'}`,
                background: game === g ? 'rgba(0,212,255,0.1)' : 'transparent',
                color: game === g ? 'var(--accent-primary)' : 'var(--text-secondary)',
                cursor: 'pointer', borderRadius: '6px', transition: 'all 0.2s',
              }}>
                {g}
              </button>
            ))}
          </div>

          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '60px' }}>
              <div className="loading-spinner" />
            </div>
          ) : (
            <div>
              {/* Header */}
              <div style={{ display: 'grid', gridTemplateColumns: '60px 1fr 140px 100px', gap: '12px', padding: '8px 20px', marginBottom: '8px' }}>
                {['RANK', 'PLAYER', 'GAME', 'SCORE'].map(h => (
                  <span key={h} style={{ fontFamily: 'Orbitron, monospace', fontSize: '0.65rem', color: 'var(--text-secondary)', letterSpacing: '0.15em' }}>{h}</span>
                ))}
              </div>
              {filtered.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-secondary)' }}>
                  <p style={{ fontSize: '2rem' }}>🏆</p>
                  <p style={{ fontFamily: 'Orbitron, monospace', fontSize: '0.9rem', marginTop: '8px' }}>No scores yet. Be the first!</p>
                </div>
              ) : (
                filtered.map((s, idx) => (
                  <div key={s._id} className="leaderboard-row" style={{ gridTemplateColumns: '60px 1fr 140px 100px' }}>
                    <span className={`rank-badge rank-${idx < 3 ? idx+1 : 'other'}`}>{idx+1}</span>
                    <div style={{ minWidth: 0 }}>
                      <p style={{ fontFamily: 'Orbitron, monospace', fontWeight: 700, fontSize: '0.9rem', color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.playerName}</p>
                      <p style={{ color: 'var(--text-secondary)', fontSize: '0.7rem' }}>{new Date(s.createdAt).toLocaleDateString()}</p>
                    </div>
                    <span style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', display: 'flex', alignItems: 'center' }}>{s.gameName}</span>
                    <span style={{ fontFamily: 'Orbitron, monospace', fontWeight: 700, fontSize: '1rem', color: 'var(--accent-primary)', textShadow: '0 0 10px var(--accent-primary)', display: 'flex', alignItems: 'center' }}>
                      {s.score?.toLocaleString()}
                    </span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
