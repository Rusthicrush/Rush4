import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]';
import connectDB from '../../../lib/mongodb';
import News from '../../../models/News';

export default async function handler(req, res) {
  await connectDB();
  const { id } = req.query;

  if (req.method === 'GET') {
    const news = await News.findOne({ $or: [{ _id: id.match(/^[0-9a-fA-F]{24}$/) ? id : null }, { slug: id }] }).lean();
    if (!news) return res.status(404).json({ error: 'Not found' });
    await News.findByIdAndUpdate(news._id, { $inc: { views: 1 } });
    return res.status(200).json({ news });
  }

  const session = await getServerSession(req, res, authOptions);
  if (!session || !session.user.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }

  if (req.method === 'PUT') {
    const updates = { ...req.body, updatedAt: new Date() };
    const news = await News.findByIdAndUpdate(id, updates, { new: true });
    return res.status(200).json({ news });
  }

  if (req.method === 'DELETE') {
    await News.findByIdAndDelete(id);
    return res.status(200).json({ message: 'Deleted' });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
