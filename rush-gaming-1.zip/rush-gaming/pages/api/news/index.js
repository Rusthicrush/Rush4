import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]';
import connectDB from '../../../lib/mongodb';
import News from '../../../models/News';

function slugify(text) {
  return text.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').trim();
}

export default async function handler(req, res) {
  await connectDB();

  if (req.method === 'GET') {
    const { limit = 10, page = 1, category, featured } = req.query;
    const query = { published: true };
    if (category) query.category = category;

    const news = await News.find(query)
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit))
      .lean();

    const total = await News.countDocuments(query);
    return res.status(200).json({ news, total, pages: Math.ceil(total / limit) });
  }

  // Admin-only routes
  const session = await getServerSession(req, res, authOptions);
  if (!session || !session.user.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }

  if (req.method === 'POST') {
    const { title, excerpt, content, imageUrl, category, tags } = req.body;
    if (!title || !excerpt || !content) {
      return res.status(400).json({ error: 'Title, excerpt, and content are required' });
    }

    let slug = slugify(title);
    const existing = await News.findOne({ slug });
    if (existing) slug = `${slug}-${Date.now()}`;

    const news = await News.create({
      title: title.trim(),
      slug,
      excerpt: excerpt.trim(),
      content: content.trim(),
      imageUrl: imageUrl || '',
      category: category || 'Gaming',
      tags: tags || [],
    });

    return res.status(201).json({ news });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
