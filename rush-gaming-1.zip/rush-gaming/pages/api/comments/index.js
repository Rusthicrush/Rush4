import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]';
import connectDB from '../../../lib/mongodb';
import Comment from '../../../models/Comment';
import { sendCommentNotification } from '../../../lib/email';
import sanitizeHtml from 'isomorphic-dompurify';

const rateLimit = new Map();

function checkRateLimit(ip) {
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute
  const maxRequests = 3;

  if (!rateLimit.has(ip)) {
    rateLimit.set(ip, { count: 1, resetTime: now + windowMs });
    return true;
  }

  const data = rateLimit.get(ip);
  if (now > data.resetTime) {
    rateLimit.set(ip, { count: 1, resetTime: now + windowMs });
    return true;
  }

  if (data.count >= maxRequests) return false;
  data.count++;
  return true;
}

export default async function handler(req, res) {
  await connectDB();

  if (req.method === 'GET') {
    const { pageSlug, limit = 20, page = 1 } = req.query;
    const query = { approved: true };
    if (pageSlug) query.pageSlug = pageSlug;

    const comments = await Comment.find(query)
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit))
      .lean();

    const total = await Comment.countDocuments(query);
    return res.status(200).json({ comments, total, pages: Math.ceil(total / limit) });
  }

  if (req.method === 'POST') {
    const session = await getServerSession(req, res, authOptions);
    if (!session) {
      return res.status(401).json({ error: 'Sign in required to comment' });
    }

    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    if (!checkRateLimit(ip)) {
      return res.status(429).json({ error: 'Too many comments. Please wait before posting again.' });
    }

    const { comment, pageName, pageSlug } = req.body;

    if (!comment || !pageName || !pageSlug) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const clean = sanitizeHtml.sanitize ? sanitizeHtml.sanitize(comment.trim()) : comment.trim();

    if (!clean || clean.length < 3) {
      return res.status(400).json({ error: 'Comment is too short' });
    }

    if (clean.length > 1000) {
      return res.status(400).json({ error: 'Comment is too long (max 1000 characters)' });
    }

    const newComment = await Comment.create({
      commenterName: session.user.name,
      commenterEmail: session.user.email,
      provider: session.user.provider || 'google',
      comment: clean,
      pageName: pageName.trim(),
      pageSlug: pageSlug.toLowerCase().trim(),
    });

    // Send email notification (non-blocking)
    sendCommentNotification({
      commenterName: session.user.name,
      commenterEmail: session.user.email,
      provider: session.user.provider || 'google',
      comment: clean,
      pageName: pageName.trim(),
    }).catch(console.error);

    return res.status(201).json({ comment: newComment });
  }

  if (req.method === 'DELETE') {
    const session = await getServerSession(req, res, authOptions);
    if (!session || !session.user.isAdmin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const { id } = req.query;
    await Comment.findByIdAndDelete(id);
    return res.status(200).json({ message: 'Comment deleted' });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
