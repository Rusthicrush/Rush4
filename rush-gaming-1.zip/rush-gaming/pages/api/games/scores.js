import connectDB from '../../../lib/mongodb';
import Score from '../../../models/Score';

export default async function handler(req, res) {
  await connectDB();

  if (req.method === 'GET') {
    const { gameSlug, limit = 10 } = req.query;
    const query = gameSlug ? { gameSlug } : {};
    const scores = await Score.find(query)
      .sort({ score: -1 })
      .limit(parseInt(limit))
      .lean();
    return res.status(200).json({ scores });
  }

  if (req.method === 'POST') {
    const { playerName, gameSlug, gameName, score } = req.body;
    if (!playerName || !gameSlug || !gameName || score === undefined) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    if (playerName.length > 20) return res.status(400).json({ error: 'Name too long' });
    if (score < 0 || score > 9999999) return res.status(400).json({ error: 'Invalid score' });

    const entry = await Score.create({
      playerName: playerName.trim(),
      gameSlug,
      gameName,
      score: parseInt(score),
    });

    return res.status(201).json({ entry });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
