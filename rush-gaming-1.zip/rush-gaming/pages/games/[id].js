import { useEffect, useRef, useState } from 'react';
import Layout from '../../components/Layout';
import CommentsSection from '../../components/CommentsSection';
import Link from 'next/link';

const GAME_CONFIGS = {
  'space-battle': {
    name: 'Space Battle',
    emoji: '🚀',
    desc: 'Defend the galaxy! Arrow keys to move, Space to shoot.',
    instructions: 'Use ← → to move. Press SPACE to fire. Destroy all aliens before they reach you!',
    component: SpaceBattleGame,
  },
  'snake-game': {
    name: 'Snake Game',
    emoji: '🐍',
    desc: 'Classic neon snake. Eat stars, grow longer!',
    instructions: 'Use arrow keys or WASD to move your snake. Eat glowing orbs to grow. Avoid walls and yourself!',
    component: SnakeGame,
  },
  'car-racing': {
    name: 'Car Racing',
    emoji: '🏎️',
    desc: 'High-speed neon highway racing!',
    instructions: 'Use ← → or A/D to dodge obstacles. Survive as long as possible and set a high score!',
    component: CarRacingGame,
  },
  'chess': {
    name: 'Chess',
    emoji: '♟️',
    desc: 'Strategic galaxy chess. Click to select and move.',
    instructions: 'Click a piece to select it, then click a highlighted square to move. Play vs yourself!',
    component: ChessGame,
  },
  'puzzle-blast': {
    name: 'Puzzle Blast',
    emoji: '💎',
    desc: 'Match 3 gems to blast them!',
    instructions: 'Click 2 adjacent gems to swap them. Match 3+ in a row to blast! Reach the target score!',
    component: PuzzleBlastGame,
  },
  'memory-cards': {
    name: 'Memory Cards',
    emoji: '🃏',
    desc: 'Flip cards to find matching pairs!',
    instructions: 'Click cards to flip them. Find all matching pairs. Fewer moves = higher score!',
    component: MemoryCardsGame,
  },
  'tic-tac-toe': {
    name: 'Tic Tac Toe',
    emoji: '❌',
    desc: 'Classic Tic Tac Toe vs AI!',
    instructions: 'You are X, AI is O. Click a cell to place your mark. Get 3 in a row to win!',
    component: TicTacToeGame,
  },
  'block-puzzle': {
    name: 'Block Puzzle',
    emoji: '🟦',
    desc: 'Fit blocks and clear lines!',
    instructions: 'Drag blocks onto the grid. Complete rows or columns to clear them. Game over when no block fits!',
    component: BlockPuzzleGame,
  },
  'running-game': {
    name: 'Galaxy Runner',
    emoji: '🏃',
    desc: 'Run through the endless galaxy!',
    instructions: 'Press SPACE or click/tap to jump. Jump over obstacles. Survive as long as you can!',
    component: RunningGame,
  },
  'shooting-game': {
    name: 'Shooting Range',
    emoji: '🎯',
    desc: 'Click moving targets to score!',
    instructions: 'Click on the moving targets as fast as you can. Targets get smaller and faster over time!',
    component: ShootingGame,
  },
};

// ============================================================
// GAME: SPACE BATTLE
// ============================================================
function SpaceBattleGame({ onScore }) {
  const canvasRef = useRef(null);
  const gameRef = useRef({ running: false, score: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = 600;
    const H = canvas.height = 480;

    let player = { x: W/2, y: H-60, w: 36, h: 36, speed: 6 };
    let bullets = [];
    let aliens = [];
    let particles = [];
    let score = 0;
    let lives = 3;
    let wave = 1;
    let gameOver = false;
    let frame = 0;
    let keys = {};

    const spawnAliens = () => {
      for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 8; c++) {
          aliens.push({ x: 80 + c*60, y: 40 + r*50, w: 28, h: 28, dir: 1, speed: 0.8 + wave*0.2 });
        }
      }
    };
    spawnAliens();

    const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent-primary').trim() || '#00d4ff';

    const addParticle = (x, y, color) => {
      for (let i = 0; i < 8; i++) {
        particles.push({ x, y, vx: (Math.random()-0.5)*4, vy: (Math.random()-0.5)*4, life: 30, color });
      }
    };

    const draw = () => {
      ctx.fillStyle = '#000a1f';
      ctx.fillRect(0, 0, W, H);

      // Stars
      ctx.fillStyle = 'rgba(255,255,255,0.3)';
      for (let i = 0; i < 80; i++) {
        const sx = (i * 73) % W;
        const sy = ((i * 137 + frame * 0.3) % H + H) % H;
        ctx.fillRect(sx, sy, 1, 1);
      }

      if (!gameOver) {
        // Player
        ctx.save();
        ctx.shadowBlur = 20;
        ctx.shadowColor = accentColor;
        ctx.fillStyle = accentColor;
        ctx.beginPath();
        ctx.moveTo(player.x, player.y);
        ctx.lineTo(player.x - 16, player.y + 36);
        ctx.lineTo(player.x + 16, player.y + 36);
        ctx.closePath();
        ctx.fill();
        ctx.restore();

        // Bullets
        bullets.forEach(b => {
          ctx.save();
          ctx.shadowBlur = 12;
          ctx.shadowColor = accentColor;
          ctx.fillStyle = accentColor;
          ctx.fillRect(b.x - 2, b.y - 8, 4, 16);
          ctx.restore();
        });

        // Aliens
        aliens.forEach(a => {
          ctx.save();
          ctx.shadowBlur = 10;
          ctx.shadowColor = '#ff3200';
          ctx.fillStyle = '#ff3200';
          ctx.font = '22px serif';
          ctx.textAlign = 'center';
          ctx.fillText('👾', a.x, a.y + 14);
          ctx.restore();
        });

        // Particles
        particles.forEach(p => {
          ctx.save();
          ctx.globalAlpha = p.life / 30;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, 3, 0, Math.PI*2);
          ctx.fill();
          ctx.restore();
        });

        // HUD
        ctx.fillStyle = accentColor;
        ctx.font = '14px Orbitron, monospace';
        ctx.textAlign = 'left';
        ctx.fillText(`SCORE: ${score}`, 12, 24);
        ctx.textAlign = 'right';
        ctx.fillText(`LIVES: ${'♥'.repeat(lives)}  WAVE: ${wave}`, W-12, 24);
      } else {
        ctx.fillStyle = accentColor;
        ctx.font = 'bold 36px Orbitron, monospace';
        ctx.textAlign = 'center';
        ctx.fillText('GAME OVER', W/2, H/2 - 30);
        ctx.font = '20px Orbitron, monospace';
        ctx.fillText(`SCORE: ${score}`, W/2, H/2 + 20);
        ctx.font = '14px Orbitron, monospace';
        ctx.fillStyle = '#888';
        ctx.fillText('Press R to restart', W/2, H/2 + 60);
      }
    };

    const update = () => {
      if (gameOver) return;
      frame++;

      if (keys['ArrowLeft'] || keys['a']) player.x = Math.max(20, player.x - player.speed);
      if (keys['ArrowRight'] || keys['d']) player.x = Math.min(W-20, player.x + player.speed);

      // Auto-shoot every 12 frames
      if (frame % 12 === 0) {
        bullets.push({ x: player.x, y: player.y });
      }

      bullets.forEach(b => { b.y -= 10; });
      bullets = bullets.filter(b => b.y > -10);

      // Move aliens
      let hitWall = false;
      aliens.forEach(a => { a.x += a.dir * a.speed; if (a.x > W-30 || a.x < 30) hitWall = true; });
      if (hitWall) { aliens.forEach(a => { a.dir *= -1; a.y += 20; }); }

      // Bullet-alien collision
      bullets = bullets.filter(b => {
        for (let i = aliens.length - 1; i >= 0; i--) {
          const a = aliens[i];
          if (Math.abs(b.x - a.x) < 18 && Math.abs(b.y - a.y) < 18) {
            addParticle(a.x, a.y, '#ff3200');
            aliens.splice(i, 1);
            score += 10;
            return false;
          }
        }
        return true;
      });

      // Alien reaches bottom
      if (aliens.some(a => a.y > H - 80)) {
        lives--;
        if (lives <= 0) {
          gameOver = true;
          onScore && onScore(score);
        } else {
          aliens = aliens.filter(a => a.y <= H - 80);
        }
      }

      // Wave clear
      if (aliens.length === 0) {
        wave++;
        spawnAliens();
      }

      // Update particles
      particles.forEach(p => { p.x += p.vx; p.y += p.vy; p.life--; });
      particles = particles.filter(p => p.life > 0);
    };

    let animId;
    const loop = () => {
      update();
      draw();
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);

    const onKey = (e, down) => {
      keys[e.key] = down;
      if (down && e.key === 'r' && gameOver) {
        score = 0; lives = 3; wave = 1; gameOver = false; frame = 0;
        bullets = []; particles = []; aliens = [];
        player.x = W/2;
        spawnAliens();
      }
    };

    window.addEventListener('keydown', e => onKey(e, true));
    window.addEventListener('keyup', e => onKey(e, false));

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', e => onKey(e, true));
      window.removeEventListener('keyup', e => onKey(e, false));
    };
  }, []);

  return <canvas ref={canvasRef} style={{ maxWidth: '100%', display: 'block', margin: '0 auto' }} />;
}

// ============================================================
// GAME: SNAKE
// ============================================================
function SnakeGame({ onScore }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = 480;
    const H = canvas.height = 480;
    const CELL = 20;
    const COLS = W / CELL;
    const ROWS = H / CELL;

    const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent-primary').trim() || '#00d4ff';

    let snake = [{ x: 10, y: 10 }];
    let dir = { x: 1, y: 0 };
    let nextDir = { x: 1, y: 0 };
    let food = { x: 15, y: 15 };
    let score = 0;
    let gameOver = false;
    let interval;

    const placeFood = () => {
      food = { x: Math.floor(Math.random() * COLS), y: Math.floor(Math.random() * ROWS) };
    };

    const draw = () => {
      ctx.fillStyle = '#000a1f';
      ctx.fillRect(0, 0, W, H);

      // Grid
      ctx.strokeStyle = 'rgba(0,212,255,0.05)';
      ctx.lineWidth = 0.5;
      for (let i = 0; i < COLS; i++) { ctx.beginPath(); ctx.moveTo(i*CELL, 0); ctx.lineTo(i*CELL, H); ctx.stroke(); }
      for (let i = 0; i < ROWS; i++) { ctx.beginPath(); ctx.moveTo(0, i*CELL); ctx.lineTo(W, i*CELL); ctx.stroke(); }

      // Snake
      snake.forEach((seg, i) => {
        const alpha = 0.4 + (i / snake.length) * 0.6;
        ctx.save();
        ctx.shadowBlur = i === 0 ? 20 : 6;
        ctx.shadowColor = accentColor;
        ctx.fillStyle = i === 0 ? accentColor : `rgba(0, 180, 255, ${alpha})`;
        ctx.fillRect(seg.x*CELL+1, seg.y*CELL+1, CELL-2, CELL-2);
        ctx.restore();
      });

      // Food
      ctx.save();
      ctx.shadowBlur = 20;
      ctx.shadowColor = '#ff3200';
      ctx.fillStyle = '#ff6600';
      ctx.beginPath();
      ctx.arc(food.x*CELL + CELL/2, food.y*CELL + CELL/2, CELL/2-2, 0, Math.PI*2);
      ctx.fill();
      ctx.restore();

      // Score
      ctx.fillStyle = accentColor;
      ctx.font = '14px Orbitron, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`SCORE: ${score}`, 12, 24);

      if (gameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = accentColor;
        ctx.font = 'bold 32px Orbitron, monospace';
        ctx.textAlign = 'center';
        ctx.fillText('GAME OVER', W/2, H/2 - 20);
        ctx.font = '18px Orbitron, monospace';
        ctx.fillText(`SCORE: ${score}`, W/2, H/2 + 20);
        ctx.font = '13px Orbitron, monospace';
        ctx.fillStyle = '#888';
        ctx.fillText('Press R to restart', W/2, H/2 + 60);
      }
    };

    const update = () => {
      if (gameOver) return;
      dir = { ...nextDir };
      const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };

      if (head.x < 0 || head.x >= COLS || head.y < 0 || head.y >= ROWS) { end(); return; }
      if (snake.some(s => s.x === head.x && s.y === head.y)) { end(); return; }

      snake.unshift(head);
      if (head.x === food.x && head.y === food.y) {
        score += 10;
        placeFood();
      } else {
        snake.pop();
      }
      draw();
    };

    const end = () => {
      gameOver = true;
      clearInterval(interval);
      draw();
      onScore && onScore(score);
    };

    interval = setInterval(update, 120);
    draw();

    const onKey = (e) => {
      if (e.key === 'ArrowUp' && dir.y !== 1) nextDir = { x: 0, y: -1 };
      if (e.key === 'ArrowDown' && dir.y !== -1) nextDir = { x: 0, y: 1 };
      if (e.key === 'ArrowLeft' && dir.x !== 1) nextDir = { x: -1, y: 0 };
      if (e.key === 'ArrowRight' && dir.x !== -1) nextDir = { x: 1, y: 0 };
      if (e.key === 'w' && dir.y !== 1) nextDir = { x: 0, y: -1 };
      if (e.key === 's' && dir.y !== -1) nextDir = { x: 0, y: 1 };
      if (e.key === 'a' && dir.x !== 1) nextDir = { x: -1, y: 0 };
      if (e.key === 'd' && dir.x !== -1) nextDir = { x: 1, y: 0 };
      if (e.key === 'r' && gameOver) {
        snake = [{ x: 10, y: 10 }];
        dir = { x: 1, y: 0 }; nextDir = { x: 1, y: 0 };
        score = 0; gameOver = false;
        placeFood();
        interval = setInterval(update, 120);
        draw();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => { clearInterval(interval); window.removeEventListener('keydown', onKey); };
  }, []);

  return <canvas ref={canvasRef} style={{ maxWidth: '100%', display: 'block', margin: '0 auto' }} />;
}

// ============================================================
// GAME: CAR RACING
// ============================================================
function CarRacingGame({ onScore }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = 400;
    const H = canvas.height = 560;

    const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent-primary').trim() || '#00d4ff';
    let car = { x: W/2, y: H-90, w: 32, h: 56, speed: 5 };
    let obstacles = [];
    let score = 0;
    let speed = 3;
    let gameOver = false;
    let frame = 0;
    let keys = {};
    let roadOffset = 0;
    let animId;

    const spawnObstacle = () => {
      const colors = ['#ff3200', '#ff6600', '#cc0000', '#ff9900'];
      obstacles.push({
        x: 80 + Math.random() * (W - 160),
        y: -80,
        w: 30 + Math.random() * 20,
        h: 50,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    };

    const draw = () => {
      ctx.fillStyle = '#111';
      ctx.fillRect(0, 0, W, H);

      // Road
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(60, 0, W - 120, H);

      // Road markings
      ctx.strokeStyle = 'rgba(255,255,0,0.4)';
      ctx.lineWidth = 3;
      ctx.setLineDash([30, 20]);
      ctx.lineDashOffset = -roadOffset;
      [W/2 - 40, W/2 + 40].forEach(x => {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
      });
      ctx.setLineDash([]);

      // Grass
      ctx.fillStyle = '#0a1a0a';
      ctx.fillRect(0, 0, 60, H);
      ctx.fillRect(W-60, 0, 60, H);

      // Obstacles
      obstacles.forEach(o => {
        ctx.save();
        ctx.shadowBlur = 10;
        ctx.shadowColor = o.color;
        ctx.fillStyle = o.color;
        ctx.fillRect(o.x - o.w/2, o.y, o.w, o.h);
        ctx.fillStyle = 'rgba(255,255,255,0.2)';
        ctx.fillRect(o.x - o.w/2 + 4, o.y + 6, 8, o.h - 12);
        ctx.restore();
      });

      // Player Car
      ctx.save();
      ctx.shadowBlur = 20;
      ctx.shadowColor = accentColor;
      ctx.fillStyle = accentColor;
      ctx.fillRect(car.x - car.w/2, car.y, car.w, car.h);
      ctx.fillStyle = '#fff';
      ctx.fillRect(car.x - car.w/2 + 4, car.y + 8, 10, car.h - 20);
      ctx.restore();

      // HUD
      ctx.fillStyle = accentColor;
      ctx.font = '14px Orbitron, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`SCORE: ${score}`, 8, 24);
      ctx.textAlign = 'right';
      ctx.fillText(`SPEED: ${Math.floor(speed * 10)}`, W - 8, 24);

      if (gameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.75)';
        ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = accentColor;
        ctx.font = 'bold 28px Orbitron, monospace';
        ctx.textAlign = 'center';
        ctx.fillText('GAME OVER', W/2, H/2 - 20);
        ctx.font = '18px Orbitron, monospace';
        ctx.fillText(`SCORE: ${score}`, W/2, H/2 + 20);
        ctx.font = '13px Orbitron, monospace';
        ctx.fillStyle = '#888';
        ctx.fillText('Press R to restart', W/2, H/2 + 55);
      }
    };

    const update = () => {
      if (gameOver) return;
      frame++;
      roadOffset = (roadOffset + speed) % 50;
      if (keys['ArrowLeft'] || keys['a']) car.x = Math.max(70, car.x - car.speed);
      if (keys['ArrowRight'] || keys['d']) car.x = Math.min(W-70, car.x + car.speed);

      if (frame % Math.max(30, 60 - Math.floor(speed)) === 0) spawnObstacle();

      speed = 3 + frame / 600;
      score = Math.floor(frame / 6);

      obstacles.forEach(o => { o.y += speed; });
      obstacles = obstacles.filter(o => o.y < H + 100);

      // Collision
      if (obstacles.some(o =>
        Math.abs(o.x - car.x) < (o.w + car.w)/2 - 4 &&
        o.y + o.h > car.y + 8 && o.y < car.y + car.h - 8
      )) {
        gameOver = true;
        onScore && onScore(score);
      }
    };

    const loop = () => { update(); draw(); animId = requestAnimationFrame(loop); };
    animId = requestAnimationFrame(loop);

    const onKey = (e, down) => {
      keys[e.key] = down;
      if (down && e.key === 'r' && gameOver) {
        car.x = W/2; score = 0; speed = 3; frame = 0; gameOver = false; obstacles = [];
      }
    };
    window.addEventListener('keydown', e => onKey(e, true));
    window.addEventListener('keyup', e => onKey(e, false));
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', e => onKey(e, true));
      window.removeEventListener('keyup', e => onKey(e, false));
    };
  }, []);

  return <canvas ref={canvasRef} style={{ maxWidth: '100%', display: 'block', margin: '0 auto' }} />;
}

// ============================================================
// GAME: CHESS
// ============================================================
function ChessGame() {
  const [board, setBoard] = useState(() => initChess());
  const [selected, setSelected] = useState(null);
  const [moves, setMoves] = useState([]);
  const [turn, setTurn] = useState('w');
  const [status, setStatus] = useState('White to move');

  function initChess() {
    const b = Array(8).fill(null).map(() => Array(8).fill(null));
    const backRow = ['R','N','B','Q','K','B','N','R'];
    for (let i = 0; i < 8; i++) {
      b[0][i] = { piece: backRow[i], color: 'b' };
      b[1][i] = { piece: 'P', color: 'b' };
      b[6][i] = { piece: 'P', color: 'w' };
      b[7][i] = { piece: backRow[i], color: 'w' };
    }
    return b;
  }

  const pieceEmoji = { wK:'♔', wQ:'♕', wR:'♖', wB:'♗', wN:'♘', wP:'♙', bK:'♚', bQ:'♛', bR:'♜', bB:'♝', bN:'♞', bP:'♟' };

  const handleClick = (r, c) => {
    const cell = board[r][c];
    if (selected) {
      if (moves.some(m => m[0] === r && m[1] === c)) {
        const nb = board.map(row => row.map(cell => cell ? {...cell} : null));
        nb[r][c] = nb[selected[0]][selected[1]];
        nb[selected[0]][selected[1]] = null;
        setBoard(nb);
        setSelected(null);
        setMoves([]);
        setTurn(t => t === 'w' ? 'b' : 'w');
        setStatus(turn === 'w' ? 'Black to move' : 'White to move');
        return;
      }
      setSelected(null);
      setMoves([]);
    }
    if (cell && cell.color === turn) {
      setSelected([r, c]);
      setMoves(getBasicMoves(board, r, c, cell));
    }
  };

  function getBasicMoves(b, r, c, piece) {
    const ms = [];
    const add = (nr, nc) => {
      if (nr < 0 || nr > 7 || nc < 0 || nc > 7) return false;
      if (b[nr][nc] && b[nr][nc].color === piece.color) return false;
      ms.push([nr, nc]);
      return !b[nr][nc];
    };
    if (piece.piece === 'P') {
      const d = piece.color === 'w' ? -1 : 1;
      if (!b[r+d]?.[c]) { add(r+d, c); if ((piece.color === 'w' ? r === 6 : r === 1) && !b[r+2*d]?.[c]) add(r+2*d, c); }
      [c-1, c+1].forEach(nc => { if (b[r+d]?.[nc] && b[r+d][nc].color !== piece.color) add(r+d, nc); });
    } else if (piece.piece === 'N') {
      [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]].forEach(([dr,dc]) => add(r+dr, c+dc));
    } else if (piece.piece === 'K') {
      for (let dr=-1; dr<=1; dr++) for (let dc=-1; dc<=1; dc++) if (dr||dc) add(r+dr, c+dc);
    } else {
      const dirs = piece.piece === 'R' ? [[0,1],[0,-1],[1,0],[-1,0]] :
                   piece.piece === 'B' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                   [[0,1],[0,-1],[1,0],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]];
      dirs.forEach(([dr,dc]) => {
        let nr = r+dr, nc = c+dc;
        while (add(nr, nc)) { nr += dr; nc += dc; }
      });
    }
    return ms;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' }}>
      <p style={{ color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', fontSize: '0.85rem' }}>{status}</p>
      <div style={{ border: '2px solid var(--accent-primary)', boxShadow: '0 0 20px var(--accent-primary)' }}>
        {board.map((row, r) => (
          <div key={r} style={{ display: 'flex' }}>
            {row.map((cell, c) => {
              const isLight = (r + c) % 2 === 0;
              const isSelected = selected && selected[0] === r && selected[1] === c;
              const isMove = moves.some(m => m[0] === r && m[1] === c);
              return (
                <div key={c} onClick={() => handleClick(r, c)} style={{
                  width: '54px', height: '54px',
                  background: isSelected ? 'rgba(0,212,255,0.4)' : isMove ? 'rgba(0,255,100,0.3)' : isLight ? 'rgba(0,50,100,0.5)' : 'rgba(0,10,40,0.8)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  cursor: 'pointer',
                  fontSize: '1.8rem',
                  transition: 'background 0.2s',
                  position: 'relative',
                  boxShadow: isMove ? 'inset 0 0 8px rgba(0,255,100,0.4)' : 'none',
                }}>
                  {isMove && !cell && <div style={{ width: '16px', height: '16px', borderRadius: '50%', background: 'rgba(0,255,100,0.5)' }} />}
                  {cell && pieceEmoji[cell.color + cell.piece]}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      <button className="neon-btn" onClick={() => { setBoard(initChess()); setSelected(null); setMoves([]); setTurn('w'); setStatus('White to move'); }} style={{ padding: '8px 24px', fontSize: '0.75rem' }}>
        New Game
      </button>
    </div>
  );
}

// ============================================================
// GAME: PUZZLE BLAST (Match-3)
// ============================================================
function PuzzleBlastGame({ onScore }) {
  const GEMS = ['💎', '🔴', '🟡', '🟢', '🔵', '🟣'];
  const SIZE = 7;
  const initGrid = () => Array(SIZE).fill(null).map(() => Array(SIZE).fill(null).map(() => GEMS[Math.floor(Math.random() * GEMS.length)]));
  const [grid, setGrid] = useState(initGrid);
  const [sel, setSel] = useState(null);
  const [score, setScore] = useState(0);
  const [moves, setMovesLeft] = useState(25);

  const checkMatches = (g) => {
    const toRemove = new Set();
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE - 2; c++) {
        if (g[r][c] && g[r][c] === g[r][c+1] && g[r][c] === g[r][c+2]) {
          toRemove.add(`${r},${c}`); toRemove.add(`${r},${c+1}`); toRemove.add(`${r},${c+2}`);
        }
      }
    }
    for (let c = 0; c < SIZE; c++) {
      for (let r = 0; r < SIZE - 2; r++) {
        if (g[r][c] && g[r][c] === g[r+1][c] && g[r][c] === g[r+2][c]) {
          toRemove.add(`${r},${c}`); toRemove.add(`${r+1},${c}`); toRemove.add(`${r+2},${c}`);
        }
      }
    }
    if (toRemove.size > 0) {
      const ng = g.map(row => [...row]);
      let pts = 0;
      toRemove.forEach(k => { const [r,c] = k.split(',').map(Number); ng[r][c] = null; pts += 10; });
      for (let c = 0; c < SIZE; c++) {
        let empty = SIZE - 1;
        for (let r = SIZE - 1; r >= 0; r--) {
          if (ng[r][c]) { ng[empty][c] = ng[r][c]; if (empty !== r) ng[r][c] = null; empty--; }
        }
        for (let r = empty; r >= 0; r--) ng[r][c] = GEMS[Math.floor(Math.random() * GEMS.length)];
      }
      setScore(s => s + pts);
      return ng;
    }
    return g;
  };

  const handleClick = (r, c) => {
    if (moves <= 0) return;
    if (!sel) { setSel([r,c]); return; }
    const [sr, sc] = sel;
    if (Math.abs(r-sr) + Math.abs(c-sc) === 1) {
      const ng = grid.map(row => [...row]);
      [ng[r][c], ng[sr][sc]] = [ng[sr][sc], ng[r][c]];
      const after = checkMatches(ng);
      setGrid(after);
      setMovesLeft(m => m - 1);
      if (moves - 1 <= 0) onScore && onScore(score);
    }
    setSel(null);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' }}>
      <div style={{ display: 'flex', gap: '24px' }}>
        <span style={{ color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', fontSize: '0.85rem' }}>SCORE: {score}</span>
        <span style={{ color: 'var(--text-secondary)', fontFamily: 'Orbitron, monospace', fontSize: '0.85rem' }}>MOVES: {moves}</span>
      </div>
      <div style={{ border: '2px solid var(--border-color)', borderRadius: '8px', overflow: 'hidden' }}>
        {grid.map((row, r) => (
          <div key={r} style={{ display: 'flex' }}>
            {row.map((gem, c) => (
              <div key={c} onClick={() => handleClick(r, c)} style={{
                width: '52px', height: '52px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '1.6rem', cursor: 'pointer',
                background: sel && sel[0]===r && sel[1]===c ? 'rgba(0,212,255,0.2)' : 'rgba(0,10,40,0.7)',
                border: '1px solid rgba(0,50,100,0.3)',
                transition: 'all 0.2s',
              }}>
                {gem}
              </div>
            ))}
          </div>
        ))}
      </div>
      <button className="neon-btn" onClick={() => { setGrid(initGrid()); setScore(0); setMovesLeft(25); setSel(null); }} style={{ padding: '8px 24px', fontSize: '0.75rem' }}>
        New Game
      </button>
    </div>
  );
}

// ============================================================
// GAME: MEMORY CARDS
// ============================================================
function MemoryCardsGame({ onScore }) {
  const EMOJIS = ['🚀','⚡','🌙','💫','🎮','🎯','🔥','💎'];
  const init = () => {
    const cards = [...EMOJIS, ...EMOJIS].map((e, i) => ({ id: i, emoji: e, flipped: false, matched: false }));
    for (let i = cards.length - 1; i > 0; i--) { const j = Math.floor(Math.random()*(i+1)); [cards[i],cards[j]] = [cards[j],cards[i]]; }
    return cards;
  };
  const [cards, setCards] = useState(init);
  const [flipped, setFlipped] = useState([]);
  const [moves, setMoves] = useState(0);
  const [won, setWon] = useState(false);

  const handleFlip = (id) => {
    if (flipped.length === 2) return;
    const card = cards.find(c => c.id === id);
    if (!card || card.flipped || card.matched) return;
    const newCards = cards.map(c => c.id === id ? { ...c, flipped: true } : c);
    const newFlipped = [...flipped, id];
    setCards(newCards);
    setFlipped(newFlipped);
    if (newFlipped.length === 2) {
      setMoves(m => m + 1);
      const [id1, id2] = newFlipped;
      const c1 = newCards.find(c => c.id === id1);
      const c2 = newCards.find(c => c.id === id2);
      if (c1.emoji === c2.emoji) {
        const matched = newCards.map(c => newFlipped.includes(c.id) ? { ...c, matched: true } : c);
        setCards(matched);
        setFlipped([]);
        if (matched.every(c => c.matched)) { setWon(true); onScore && onScore(Math.max(0, 500 - moves * 10)); }
      } else {
        setTimeout(() => {
          setCards(prev => prev.map(c => newFlipped.includes(c.id) ? { ...c, flipped: false } : c));
          setFlipped([]);
        }, 800);
      }
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
      <div style={{ display: 'flex', gap: '24px' }}>
        <span style={{ color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', fontSize: '0.85rem' }}>MOVES: {moves}</span>
        <span style={{ color: won ? '#00ff88' : 'var(--text-secondary)', fontFamily: 'Orbitron, monospace', fontSize: '0.85rem' }}>{won ? '🏆 YOU WON!' : `PAIRS: ${cards.filter(c => c.matched).length/2}/${EMOJIS.length}`}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
        {cards.map(card => (
          <div key={card.id} onClick={() => handleFlip(card.id)} style={{
            width: '70px', height: '70px',
            background: card.flipped || card.matched ? 'rgba(0,50,100,0.8)' : 'rgba(0,20,60,0.9)',
            border: `1px solid ${card.matched ? '#00ff88' : 'var(--border-color)'}`,
            borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1.8rem', cursor: 'pointer',
            transition: 'all 0.3s',
            boxShadow: card.matched ? '0 0 10px rgba(0,255,136,0.3)' : 'none',
          }}>
            {card.flipped || card.matched ? card.emoji : '❓'}
          </div>
        ))}
      </div>
      <button className="neon-btn" onClick={() => { setCards(init()); setFlipped([]); setMoves(0); setWon(false); }} style={{ padding: '8px 24px', fontSize: '0.75rem' }}>
        New Game
      </button>
    </div>
  );
}

// ============================================================
// GAME: TIC TAC TOE
// ============================================================
function TicTacToeGame() {
  const [board, setBoard] = useState(Array(9).fill(null));
  const [status, setStatus] = useState("Your turn (X)");
  const [gameOver, setGameOver] = useState(false);

  const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  const checkWin = (b, mark) => wins.some(w => w.every(i => b[i] === mark));

  const aiMove = (b) => {
    const empty = b.map((v,i) => v === null ? i : -1).filter(i => i >= 0);
    if (!empty.length) return b;
    for (const i of empty) { const t = [...b]; t[i]='O'; if (checkWin(t,'O')) return t; }
    for (const i of empty) { const t = [...b]; t[i]='X'; if (checkWin(t,'X')) { const tt = [...b]; tt[i]='O'; return tt; } }
    if (b[4] === null) { const t = [...b]; t[4]='O'; return t; }
    const idx = empty[Math.floor(Math.random()*empty.length)];
    const t = [...b]; t[idx] = 'O'; return t;
  };

  const click = (i) => {
    if (board[i] || gameOver) return;
    let nb = [...board]; nb[i] = 'X';
    if (checkWin(nb,'X')) { setBoard(nb); setStatus('🏆 You Win!'); setGameOver(true); return; }
    if (nb.every(v => v)) { setBoard(nb); setStatus('Draw!'); setGameOver(true); return; }
    nb = aiMove(nb);
    if (checkWin(nb,'O')) { setBoard(nb); setStatus('AI Wins!'); setGameOver(true); return; }
    if (nb.every(v => v)) { setBoard(nb); setStatus('Draw!'); setGameOver(true); return; }
    setBoard(nb); setStatus("Your turn (X)");
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '20px' }}>
      <p style={{ color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', fontSize: '1rem' }}>{status}</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px' }}>
        {board.map((cell, i) => (
          <div key={i} onClick={() => click(i)} style={{
            width: '100px', height: '100px',
            background: 'rgba(0,20,60,0.8)',
            border: '2px solid var(--border-color)',
            borderRadius: '8px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '2.5rem', cursor: 'pointer',
            transition: 'all 0.2s',
            color: cell === 'X' ? 'var(--accent-primary)' : '#ff6600',
            textShadow: cell ? `0 0 15px ${cell === 'X' ? 'var(--accent-primary)' : '#ff6600'}` : 'none',
          }}
          onMouseEnter={e => { if (!cell && !gameOver) e.currentTarget.style.borderColor = 'var(--accent-primary)'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border-color)'; }}
          >
            {cell}
          </div>
        ))}
      </div>
      <button className="neon-btn" onClick={() => { setBoard(Array(9).fill(null)); setStatus("Your turn (X)"); setGameOver(false); }} style={{ padding: '8px 24px', fontSize: '0.75rem' }}>
        New Game
      </button>
    </div>
  );
}

// ============================================================
// GAME: BLOCK PUZZLE
// ============================================================
function BlockPuzzleGame({ onScore }) {
  const COLS = 8, ROWS = 8;
  const init = () => ({ grid: Array(ROWS).fill(null).map(() => Array(COLS).fill(0)), score: 0, over: false });
  const SHAPES = [
    [[1,1,1]], [[1],[1],[1]], [[1,1],[1,1]], [[1,1,1],[0,1,0]], [[1,0],[1,1]], [[0,1],[1,1]]
  ];
  const [state, setState] = useState(init);
  const [dragging, setDragging] = useState(null);
  const [current, setCurrent] = useState(() => SHAPES[Math.floor(Math.random()*SHAPES.length)]);
  const [hover, setHover] = useState(null);

  const canPlace = (grid, shape, r, c) => {
    for (let sr = 0; sr < shape.length; sr++)
      for (let sc = 0; sc < shape[sr].length; sc++)
        if (shape[sr][sc] && (r+sr >= ROWS || c+sc >= COLS || grid[r+sr][c+sc])) return false;
    return true;
  };

  const place = (r, c) => {
    if (!canPlace(state.grid, current, r, c)) return;
    const ng = state.grid.map(row => [...row]);
    for (let sr = 0; sr < current.length; sr++)
      for (let sc = 0; sc < current[sr].length; sc++)
        if (current[sr][sc]) ng[r+sr][c+sc] = 1;

    let cleared = 0;
    const toKeep = ng.map((row, ri) => row.every(c => c) ? (cleared++, null) : row);
    const finalGrid = toKeep.filter(r => r !== null);
    while (finalGrid.length < ROWS) finalGrid.unshift(Array(COLS).fill(0));

    const newScore = state.score + cleared * 80 + 10;
    const next = SHAPES[Math.floor(Math.random()*SHAPES.length)];
    setState({ grid: finalGrid, score: newScore, over: false });
    setCurrent(next);
    setHover(null);
    onScore && onScore(newScore);
  };

  const CELL = 46;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
      <span style={{ color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', fontSize: '0.9rem' }}>SCORE: {state.score}</span>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${COLS}, ${CELL}px)`, gap: '3px', border: '2px solid var(--border-color)', padding: '8px', borderRadius: '8px', background: 'rgba(0,10,30,0.8)' }}>
        {state.grid.map((row, r) => row.map((cell, c) => {
          const isHover = hover && canPlace(state.grid, current, hover[0], hover[1]) &&
            current[r - hover[0]]?.[c - hover[1]];
          return (
            <div key={`${r}-${c}`}
              onClick={() => hover && place(hover[0], hover[1])}
              onMouseEnter={() => setHover([r, c])}
              style={{
                width: CELL, height: CELL,
                background: cell ? 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))' : isHover ? 'rgba(0,212,255,0.25)' : 'rgba(0,20,60,0.5)',
                border: `1px solid ${cell || isHover ? 'var(--accent-primary)' : 'rgba(0,50,100,0.4)'}`,
                borderRadius: '4px',
                cursor: 'pointer',
                boxShadow: cell ? '0 0 6px var(--accent-glow)' : 'none',
              }}
            />
          );
        }))}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>Next block (hover grid to place):</p>
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${current[0].length}, 36px)`, gap: '3px' }}>
          {current.map((row, r) => row.map((cell, c) => (
            <div key={`${r}-${c}`} style={{ width: '36px', height: '36px', background: cell ? 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))' : 'transparent', border: cell ? '1px solid var(--accent-primary)' : '1px solid transparent', borderRadius: '4px' }} />
          )))}
        </div>
      </div>
      <button className="neon-btn" onClick={() => { setState(init()); setCurrent(SHAPES[Math.floor(Math.random()*SHAPES.length)]); }} style={{ padding: '8px 24px', fontSize: '0.75rem' }}>
        New Game
      </button>
    </div>
  );
}

// ============================================================
// GAME: RUNNING GAME
// ============================================================
function RunningGame({ onScore }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = 600;
    const H = canvas.height = 280;
    const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent-primary').trim() || '#00d4ff';

    let runner = { x: 80, y: H - 70, w: 28, h: 48, vy: 0, onGround: true };
    let obstacles = [];
    let score = 0;
    let speed = 5;
    let frame = 0;
    let gameOver = false;
    let bgOffset = 0;
    let animId;
    const GROUND = H - 40;

    const jump = () => { if (runner.onGround) { runner.vy = -14; runner.onGround = false; } };

    const draw = () => {
      ctx.fillStyle = '#000a1f';
      ctx.fillRect(0, 0, W, H);

      // Moving stars
      for (let i = 0; i < 60; i++) {
        const x = ((i * 97 - bgOffset * 0.3) % W + W) % W;
        const y = (i * 37) % (GROUND - 10);
        ctx.fillStyle = `rgba(255,255,255,${0.1 + (i%5)*0.06})`;
        ctx.fillRect(x, y, 1.5, 1.5);
      }

      // Ground
      ctx.save();
      ctx.strokeStyle = accentColor;
      ctx.shadowBlur = 8;
      ctx.shadowColor = accentColor;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, GROUND);
      ctx.lineTo(W, GROUND);
      ctx.stroke();
      ctx.restore();

      // Runner
      ctx.save();
      ctx.shadowBlur = 20;
      ctx.shadowColor = accentColor;
      ctx.fillStyle = accentColor;
      ctx.fillRect(runner.x, runner.y, runner.w, runner.h);
      // "visor"
      ctx.fillStyle = '#000a1f';
      ctx.fillRect(runner.x + 8, runner.y + 8, runner.w - 12, 10);
      ctx.restore();

      // Obstacles
      obstacles.forEach(o => {
        ctx.save();
        ctx.shadowBlur = 12;
        ctx.shadowColor = '#ff3200';
        ctx.fillStyle = '#ff3200';
        ctx.fillRect(o.x, GROUND - o.h, o.w, o.h);
        ctx.restore();
      });

      // HUD
      ctx.fillStyle = accentColor;
      ctx.font = '14px Orbitron, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`SCORE: ${score}`, W - 12, 24);

      if (gameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = accentColor;
        ctx.font = 'bold 28px Orbitron, monospace';
        ctx.textAlign = 'center';
        ctx.fillText('GAME OVER', W/2, H/2 - 20);
        ctx.font = '18px Orbitron, monospace';
        ctx.fillText(`SCORE: ${score}`, W/2, H/2 + 16);
        ctx.font = '13px Orbitron, monospace';
        ctx.fillStyle = '#888';
        ctx.fillText('SPACE / Click to restart', W/2, H/2 + 50);
      }
    };

    const update = () => {
      if (gameOver) return;
      frame++;
      bgOffset += speed;
      score = Math.floor(frame / 8);
      speed = 5 + frame / 500;

      runner.vy += 0.8;
      runner.y += runner.vy;
      if (runner.y >= GROUND - runner.h) {
        runner.y = GROUND - runner.h;
        runner.vy = 0;
        runner.onGround = true;
      }

      if (frame % Math.max(40, 80 - Math.floor(speed*3)) === 0) {
        obstacles.push({ x: W + 10, w: 20 + Math.random() * 20, h: 30 + Math.random() * 40 });
      }
      obstacles.forEach(o => { o.x -= speed; });
      obstacles = obstacles.filter(o => o.x > -50);

      if (obstacles.some(o =>
        runner.x + runner.w - 4 > o.x && runner.x + 4 < o.x + o.w &&
        runner.y + runner.h - 4 > GROUND - o.h
      )) {
        gameOver = true;
        onScore && onScore(score);
      }
    };

    const loop = () => { update(); draw(); animId = requestAnimationFrame(loop); };
    animId = requestAnimationFrame(loop);

    const restart = () => {
      if (gameOver) {
        runner = { x: 80, y: GROUND - 48, w: 28, h: 48, vy: 0, onGround: true };
        obstacles = []; score = 0; speed = 5; frame = 0; gameOver = false; bgOffset = 0;
      } else {
        jump();
      }
    };

    const onKey = (e) => { if (e.code === 'Space') { e.preventDefault(); restart(); } };
    canvas.addEventListener('click', restart);
    window.addEventListener('keydown', onKey);
    return () => {
      cancelAnimationFrame(animId);
      canvas.removeEventListener('click', restart);
      window.removeEventListener('keydown', onKey);
    };
  }, []);

  return <canvas ref={canvasRef} style={{ maxWidth: '100%', display: 'block', margin: '0 auto', cursor: 'pointer' }} />;
}

// ============================================================
// GAME: SHOOTING GAME
// ============================================================
function ShootingGame({ onScore }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = 560;
    const H = canvas.height = 420;
    const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent-primary').trim() || '#00d4ff';

    let targets = [];
    let score = 0;
    let misses = 0;
    let timeLeft = 30;
    let gameOver = false;
    let frame = 0;
    let animId;
    let lastSecond = 0;
    let effects = [];

    const spawnTarget = () => {
      const r = Math.max(15, 40 - Math.floor(score/20));
      targets.push({
        x: r + Math.random() * (W - r*2),
        y: r + Math.random() * (H - r*2 - 40),
        r,
        vx: (Math.random()-0.5) * (2 + score/50),
        vy: (Math.random()-0.5) * (2 + score/50),
        life: 100 + Math.random()*60,
        maxLife: 100 + Math.random()*60,
        hue: Math.floor(Math.random()*360),
      });
    };

    for (let i = 0; i < 4; i++) spawnTarget();

    const draw = () => {
      ctx.fillStyle = '#000a1f';
      ctx.fillRect(0, 0, W, H);

      // Grid
      ctx.strokeStyle = 'rgba(0,212,255,0.04)';
      ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 40) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
      for (let y = 0; y < H; y += 40) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

      // Targets
      targets.forEach(t => {
        const lifeAlpha = t.life / t.maxLife;
        ctx.save();
        ctx.globalAlpha = lifeAlpha;
        ctx.shadowBlur = 20;
        ctx.shadowColor = `hsl(${t.hue}, 100%, 60%)`;
        ctx.strokeStyle = `hsl(${t.hue}, 100%, 60%)`;
        ctx.lineWidth = 2;
        [t.r, t.r*0.6, t.r*0.25].forEach(r => {
          ctx.beginPath(); ctx.arc(t.x, t.y, r, 0, Math.PI*2); ctx.stroke();
        });
        ctx.fillStyle = `hsl(${t.hue}, 100%, 60%)`;
        ctx.beginPath(); ctx.arc(t.x, t.y, 3, 0, Math.PI*2); ctx.fill();
        ctx.restore();
      });

      // Effects
      effects.forEach(e => {
        ctx.save();
        ctx.globalAlpha = e.life / 20;
        ctx.strokeStyle = '#ffff00';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(e.x, e.y, (20 - e.life) * 2, 0, Math.PI*2); ctx.stroke();
        ctx.restore();
      });

      // HUD
      ctx.fillStyle = accentColor;
      ctx.font = '14px Orbitron, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`SCORE: ${score}   MISSES: ${misses}`, 12, 24);
      ctx.textAlign = 'right';

      const tColor = timeLeft <= 10 ? '#ff3200' : accentColor;
      ctx.fillStyle = tColor;
      ctx.fillText(`TIME: ${timeLeft}s`, W-12, 24);

      if (gameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.75)';
        ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = accentColor;
        ctx.font = 'bold 28px Orbitron, monospace';
        ctx.textAlign = 'center';
        ctx.fillText('TIME\'S UP!', W/2, H/2 - 20);
        ctx.font = '18px Orbitron, monospace';
        ctx.fillText(`SCORE: ${score}   ACCURACY: ${score + misses > 0 ? Math.floor(score/(score+misses)*100) : 0}%`, W/2, H/2 + 20);
        ctx.font = '13px Orbitron, monospace';
        ctx.fillStyle = '#888';
        ctx.fillText('Click to restart', W/2, H/2 + 55);
      }
    };

    const update = () => {
      if (gameOver) return;
      frame++;
      if (frame - lastSecond >= 60) { lastSecond = frame; timeLeft--; if (timeLeft <= 0) { gameOver = true; onScore && onScore(score); } }
      targets.forEach(t => {
        t.x += t.vx; t.y += t.vy;
        if (t.x < t.r || t.x > W-t.r) t.vx *= -1;
        if (t.y < t.r || t.y > H-50-t.r) t.vy *= -1;
        t.life--;
      });
      const expired = targets.filter(t => t.life <= 0).length;
      misses += expired;
      targets = targets.filter(t => t.life > 0);
      while (targets.length < 4 + Math.floor(score/30)) spawnTarget();
      effects.forEach(e => e.life--);
      effects = effects.filter(e => e.life > 0);
    };

    const onClick = (e) => {
      if (gameOver) { score = 0; misses = 0; timeLeft = 30; gameOver = false; frame = 0; lastSecond = 0; targets = []; for (let i=0;i<4;i++) spawnTarget(); return; }
      const rect = canvas.getBoundingClientRect();
      const mx = (e.clientX - rect.left) * (W / rect.width);
      const my = (e.clientY - rect.top) * (H / rect.height);
      const hit = targets.find(t => Math.hypot(mx - t.x, my - t.y) < t.r);
      if (hit) {
        score += Math.ceil(30 / hit.r * 5);
        effects.push({ x: hit.x, y: hit.y, life: 20 });
        targets = targets.filter(t => t !== hit);
      } else {
        misses++;
      }
    };

    const loop = () => { update(); draw(); animId = requestAnimationFrame(loop); };
    animId = requestAnimationFrame(loop);
    canvas.addEventListener('click', onClick);
    return () => { cancelAnimationFrame(animId); canvas.removeEventListener('click', onClick); };
  }, []);

  return <canvas ref={canvasRef} style={{ maxWidth: '100%', display: 'block', margin: '0 auto', cursor: 'crosshair' }} />;
}

// ============================================================
// MAIN PAGE COMPONENT
// ============================================================
export default function GamePage({ gameId }) {
  const router = useRouter();
  const id = gameId || router.query.id;
  const [score, setScore] = useState(null);
  const [playerName, setPlayerName] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const game = GAME_CONFIGS[id];

  if (!game) {
    return (
      <Layout title="Game Not Found">
        <div style={{ textAlign: 'center', padding: '100px 20px' }}>
          <h1 style={{ fontFamily: 'Orbitron', color: 'var(--accent-primary)', fontSize: '2rem' }}>Game Not Found</h1>
          <Link href="/games" className="neon-btn" style={{ marginTop: '20px', display: 'inline-block', textDecoration: 'none' }}>← Back to Games</Link>
        </div>
      </Layout>
    );
  }

  const GameComponent = game.component;

  const submitScore = async () => {
    if (!playerName.trim() || score === null) return;
    try {
      await fetch('/api/games/scores', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerName, gameSlug: id, gameName: game.name, score }),
      });
      setSubmitted(true);
    } catch (e) { console.error(e); }
  };

  return (
    <Layout title={game.name} description={game.desc}>
      <div style={{ padding: '40px 0 80px', position: 'relative', zIndex: 1 }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '30px' }}>
            <Link href="/games" style={{ color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.85rem' }}>Games</Link>
            <span style={{ color: 'var(--border-color)' }}>›</span>
            <span style={{ color: 'var(--accent-primary)', fontSize: '0.85rem' }}>{game.name}</span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: '30px', alignItems: 'start' }}>
            {/* Game Area */}
            <div>
              <div style={{ marginBottom: '20px' }}>
                <h1 style={{ fontFamily: 'Orbitron, monospace', fontWeight: 700, fontSize: '1.8rem', color: 'var(--text-primary)', marginBottom: '8px' }}>
                  {game.emoji} {game.name}
                </h1>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>{game.instructions}</p>
              </div>

              <div className="game-canvas-wrapper" style={{ padding: '20px' }}>
                <GameComponent onScore={(s) => setScore(s)} />
              </div>

              {/* Score submission */}
              {score !== null && !submitted && (
                <div className="glass-card" style={{ padding: '20px', marginTop: '16px' }}>
                  <p style={{ color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', fontSize: '0.85rem', marginBottom: '12px' }}>
                    🏆 GAME OVER — SCORE: {score.toLocaleString()}
                  </p>
                  <div style={{ display: 'flex', gap: '12px' }}>
                    <input
                      className="rush-input"
                      placeholder="Your name for leaderboard"
                      value={playerName}
                      onChange={e => setPlayerName(e.target.value)}
                      maxLength={20}
                      style={{ flex: 1 }}
                    />
                    <button onClick={submitScore} className="neon-btn-solid" style={{ padding: '10px 20px', fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                      Submit
                    </button>
                  </div>
                </div>
              )}
              {submitted && (
                <div style={{ background: 'rgba(0,255,136,0.08)', border: '1px solid #00ff88', borderRadius: '8px', padding: '12px 20px', marginTop: '16px', color: '#00ff88', fontFamily: 'Orbitron, monospace', fontSize: '0.8rem' }}>
                  ✓ Score submitted to leaderboard!
                </div>
              )}

              <CommentsSection pageSlug={id} pageName={game.name} />
            </div>

            {/* Sidebar */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {/* Controls */}
              <div className="glass-card" style={{ padding: '20px' }}>
                <h3 style={{ fontFamily: 'Orbitron, monospace', fontSize: '0.8rem', letterSpacing: '0.15em', color: 'var(--accent-primary)', marginBottom: '12px' }}>CONTROLS</h3>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', lineHeight: 1.7 }}>{game.instructions}</p>
              </div>

              {/* Other Games */}
              <div className="glass-card" style={{ padding: '20px' }}>
                <h3 style={{ fontFamily: 'Orbitron, monospace', fontSize: '0.8rem', letterSpacing: '0.15em', color: 'var(--accent-primary)', marginBottom: '16px' }}>MORE GAMES</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {Object.entries(GAME_CONFIGS).filter(([gId]) => gId !== id).slice(0, 5).map(([gId, g]) => (
                    <Link key={gId} href={`/games/${gId}`} style={{
                      display: 'flex', alignItems: 'center', gap: '10px',
                      padding: '8px', borderRadius: '6px',
                      background: 'rgba(0,20,60,0.4)',
                      border: '1px solid var(--border-color)',
                      textDecoration: 'none',
                      transition: 'all 0.2s',
                      color: 'var(--text-primary)',
                    }}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent-primary)'; }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border-color)'; }}
                    >
                      <span style={{ fontSize: '1.3rem' }}>{g.emoji}</span>
                      <span style={{ fontSize: '0.85rem' }}>{g.name}</span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export async function getServerSideProps({ params }) {
  return { props: { gameId: params.id } };
}
