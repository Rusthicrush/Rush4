import { useState } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';
import { useRouter } from 'next/router';

const ALL_GAMES = [
  { id: 'space-battle', name: 'Space Battle', desc: 'Defend the galaxy from endless waves of alien invaders. Upgrade weapons, dodge asteroids, and survive!', emoji: '🚀', badge: 'hot', category: 'Shooter', difficulty: 'Hard' },
  { id: 'snake-game', name: 'Snake Game', desc: 'Guide your neon snake through the galaxy. Eat stars, grow longer, avoid yourself.', emoji: '🐍', badge: 'trending', category: 'Arcade', difficulty: 'Medium' },
  { id: 'car-racing', name: 'Car Racing', desc: 'Race at hyperspeed through neon highways. Dodge obstacles and set new records.', emoji: '🏎️', badge: 'new', category: 'Racing', difficulty: 'Medium' },
  { id: 'chess', name: 'Chess Board', desc: 'Strategic galaxy chess. Classic rules with a futuristic twist. Play vs AI.', emoji: '♟️', badge: null, category: 'Strategy', difficulty: 'Hard' },
  { id: 'puzzle-blast', name: 'Puzzle Blast', desc: 'Match 3 or more gems to blast them. Combo for massive points!', emoji: '💎', badge: 'hot', category: 'Puzzle', difficulty: 'Easy' },
  { id: 'memory-cards', name: 'Memory Cards', desc: 'Flip cards to find matching pairs. Test and train your galactic memory.', emoji: '🃏', badge: null, category: 'Puzzle', difficulty: 'Easy' },
  { id: 'tic-tac-toe', name: 'Tic Tac Toe', desc: 'Classic strategy game with neon galaxy aesthetics. Beat the AI!', emoji: '❌', badge: null, category: 'Strategy', difficulty: 'Easy' },
  { id: 'block-puzzle', name: 'Block Puzzle', desc: 'Fit blocks into the grid and clear lines. How long can you last?', emoji: '🟦', badge: null, category: 'Puzzle', difficulty: 'Medium' },
  { id: 'running-game', name: 'Galaxy Runner', desc: 'Run through the endless galaxy, jump over obstacles, collect power-ups!', emoji: '🏃', badge: 'new', category: 'Arcade', difficulty: 'Medium' },
  { id: 'shooting-game', name: 'Shooting Range', desc: 'Test your aim against moving galaxy targets. Top scores on the board!', emoji: '🎯', badge: null, category: 'Shooter', difficulty: 'Medium' },
];

const CATEGORIES = ['All', 'Arcade', 'Shooter', 'Racing', 'Strategy', 'Puzzle'];

export default function Games() {
  const router = useRouter();
  const [search, setSearch] = useState(router.query.search || '');
  const [category, setCategory] = useState('All');

  const filtered = ALL_GAMES.filter(g => {
    const matchSearch = g.name.toLowerCase().includes(search.toLowerCase()) || g.desc.toLowerCase().includes(search.toLowerCase());
    const matchCat = category === 'All' || g.category === category;
    return matchSearch && matchCat;
  });

  return (
    <Layout title="Games" description="Play 10 premium browser games on RUSH Gaming">
      <div style={{ padding: '60px 0', position: 'relative', zIndex: 1 }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div style={{ textAlign: 'center', marginBottom: '50px' }}>
            <h1 className="section-header" style={{ fontSize: '2.5rem', marginBottom: '12px' }}>Game Arcade</h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '1rem' }}>10 premium games. No login required. Just play.</p>
          </div>

          {/* Filters */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', marginBottom: '30px', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  style={{
                    padding: '8px 20px',
                    fontFamily: 'Orbitron, monospace',
                    fontSize: '0.7rem',
                    letterSpacing: '0.1em',
                    textTransform: 'uppercase',
                    border: `1px solid ${category === cat ? 'var(--accent-primary)' : 'var(--border-color)'}`,
                    background: category === cat ? 'rgba(0,212,255,0.1)' : 'transparent',
                    color: category === cat ? 'var(--accent-primary)' : 'var(--text-secondary)',
                    cursor: 'pointer',
                    borderRadius: '6px',
                    transition: 'all 0.2s ease',
                  }}
                >
                  {cat}
                </button>
              ))}
            </div>
            <input
              className="rush-input"
              type="text"
              placeholder="🔍 Search games..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ maxWidth: '240px' }}
            />
          </div>

          {/* Games Grid */}
          {filtered.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '80px 20px', color: 'var(--text-secondary)' }}>
              <p style={{ fontSize: '3rem', marginBottom: '16px' }}>🔍</p>
              <p style={{ fontFamily: 'Orbitron, monospace', fontSize: '1rem' }}>No games found</p>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '24px' }}>
              {filtered.map(game => (
                <Link key={game.id} href={`/games/${game.id}`} style={{ textDecoration: 'none' }}>
                  <div className="game-card" style={{ padding: '28px', height: '100%' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                      <span style={{ fontSize: '3.5rem', lineHeight: 1 }}>{game.emoji}</span>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', alignItems: 'flex-end' }}>
                        {game.badge && <span className={`badge badge-${game.badge}`}>{game.badge}</span>}
                        <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', fontFamily: 'Orbitron, monospace' }}>{game.difficulty}</span>
                      </div>
                    </div>
                    <h3 style={{ fontFamily: 'Orbitron, monospace', fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '8px' }}>{game.name}</h3>
                    <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', lineHeight: 1.6, marginBottom: '20px', flex: 1 }}>{game.desc}</p>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.7rem', color: 'var(--accent-primary)', background: 'rgba(0,212,255,0.08)', border: '1px solid var(--border-color)', padding: '3px 10px', borderRadius: '100px', fontFamily: 'Orbitron, monospace' }}>{game.category}</span>
                      <button className="neon-btn-solid" style={{ padding: '8px 20px', fontSize: '0.7rem', border: 'none', cursor: 'pointer', textDecoration: 'none' }}>
                        PLAY
                      </button>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
