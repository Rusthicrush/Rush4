import Link from 'next/link';
import Layout from '../components/Layout';

export default function Custom404() {
  return (
    <Layout title="404 - Lost in Space">
      <div style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '40px 20px', position: 'relative', zIndex: 1 }}>
        <div>
          <div style={{ fontSize: '8rem', marginBottom: '20px', animation: 'float 3s ease-in-out infinite' }}>🚀</div>
          <h1 style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900, fontSize: 'clamp(4rem, 15vw, 8rem)', color: 'var(--accent-primary)', textShadow: '0 0 30px var(--accent-primary)', marginBottom: '8px', lineHeight: 1 }}>
            404
          </h1>
          <p style={{ fontFamily: 'Orbitron, monospace', fontSize: '1.2rem', color: 'var(--text-secondary)', letterSpacing: '0.3em', marginBottom: '16px', textTransform: 'uppercase' }}>
            Lost in Space
          </p>
          <p style={{ color: 'var(--text-secondary)', fontSize: '1rem', maxWidth: '400px', margin: '0 auto 40px', lineHeight: 1.6 }}>
            The page you're looking for has drifted into a black hole. Let's get you back to the galaxy.
          </p>
          <div style={{ display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/" className="neon-btn-solid" style={{ textDecoration: 'none', padding: '14px 36px', fontSize: '0.85rem' }}>
              🏠 Return Home
            </Link>
            <Link href="/games" className="neon-btn" style={{ textDecoration: 'none', padding: '14px 36px', fontSize: '0.85rem' }}>
              🎮 Play Games
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
}
