import { useState, useEffect } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';

const CATEGORIES = ['All', 'Gaming', 'Esports', 'Updates', 'Reviews', 'Community'];

const MOCK_NEWS = [
  { _id: '1', slug: 'rush-platform-launch', title: 'RUSH Platform Launch: The Future of Gaming is Here', excerpt: 'Welcome to RUSH — the most advanced gaming platform in the galaxy. 10 games, 5 themes, and an incredible community.', category: 'Community', createdAt: new Date().toISOString(), imageUrl: '' },
  { _id: '2', slug: 'space-battle-update', title: 'New Space Battle Update: 3 New Weapons Added', excerpt: 'The latest Space Battle update brings devastating new weapons to your arsenal. Plasma cannons, nova bombs, and ion bursts.', category: 'Updates', createdAt: new Date(Date.now()-86400000).toISOString(), imageUrl: '' },
  { _id: '3', slug: 'season-1-results', title: 'RUSH Leaderboard Season 1 Results Are In', excerpt: 'Season 1 has ended and the champions have been crowned. Congratulations to NebulaDragon for dominating Space Battle!', category: 'Esports', createdAt: new Date(Date.now()-172800000).toISOString(), imageUrl: '' },
  { _id: '4', slug: 'chess-tournament', title: 'Galaxy Chess Tournament — Sign Up Now!', excerpt: 'Compete in the first RUSH Chess tournament. Bracket-style elimination, 64 players, massive bragging rights.', category: 'Esports', createdAt: new Date(Date.now()-259200000).toISOString(), imageUrl: '' },
  { _id: '5', slug: 'theme-system-review', title: 'RUSH Theme System: Full Review of All 5 Themes', excerpt: 'From Galaxy Blue to Red Inferno, we review all 5 premium themes on the RUSH platform.', category: 'Reviews', createdAt: new Date(Date.now()-345600000).toISOString(), imageUrl: '' },
  { _id: '6', slug: 'puzzle-blast-tips', title: 'Puzzle Blast: 10 Tips to Reach the Top Score', excerpt: 'Master the art of combo chains and gem swapping with our expert tips for Puzzle Blast.', category: 'Gaming', createdAt: new Date(Date.now()-432000000).toISOString(), imageUrl: '' },
];

const catEmoji = { Gaming: '🎮', Esports: '🏆', Updates: '⚡', Reviews: '⭐', Community: '🚀' };

export default function News() {
  const [news, setNews] = useState(MOCK_NEWS);
  const [category, setCategory] = useState('All');
  const [page, setPage] = useState(1);

  useEffect(() => {
    fetch('/api/news?limit=20')
      .then(r => r.json())
      .then(d => { if (d.news?.length) setNews(d.news); })
      .catch(() => {});
  }, []);

  const filtered = category === 'All' ? news : news.filter(n => n.category === category);

  return (
    <Layout title="News" description="Latest gaming news on RUSH Gaming">
      <div style={{ padding: '60px 0 80px', position: 'relative', zIndex: 1 }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div style={{ textAlign: 'center', marginBottom: '50px' }}>
            <h1 className="section-header" style={{ fontSize: '2.5rem', marginBottom: '12px' }}>Gaming News</h1>
            <p style={{ color: 'var(--text-secondary)' }}>Daily updates from the galaxy gaming universe</p>
          </div>

          {/* Category Filter */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '40px', justifyContent: 'center' }}>
            {CATEGORIES.map(cat => (
              <button key={cat} onClick={() => setCategory(cat)} style={{
                padding: '8px 20px',
                fontFamily: 'Orbitron, monospace', fontSize: '0.7rem', letterSpacing: '0.1em',
                textTransform: 'uppercase',
                border: `1px solid ${category === cat ? 'var(--accent-primary)' : 'var(--border-color)'}`,
                background: category === cat ? 'rgba(0,212,255,0.1)' : 'transparent',
                color: category === cat ? 'var(--accent-primary)' : 'var(--text-secondary)',
                cursor: 'pointer', borderRadius: '6px', transition: 'all 0.2s',
              }}>
                {catEmoji[cat] || '📰'} {cat}
              </button>
            ))}
          </div>

          {/* News Grid */}
          {filtered.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '80px', color: 'var(--text-secondary)' }}>
              <p style={{ fontSize: '3rem' }}>📰</p>
              <p style={{ fontFamily: 'Orbitron, monospace' }}>No news in this category yet</p>
            </div>
          ) : (
            <>
              {/* Featured */}
              <div style={{ marginBottom: '30px' }}>
                <Link href={`/news/${filtered[0].slug || filtered[0]._id}`} style={{ textDecoration: 'none' }}>
                  <div className="news-card" style={{ padding: '40px', position: 'relative', overflow: 'hidden' }}>
                    <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '4px', background: 'linear-gradient(90deg, var(--accent-primary), var(--accent-secondary))' }} />
                    <span className={`badge badge-hot`} style={{ marginBottom: '16px', display: 'inline-block' }}>FEATURED</span>
                    <h2 style={{ fontFamily: 'Orbitron, monospace', fontSize: '1.6rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '12px', lineHeight: 1.3 }}>{filtered[0].title}</h2>
                    <p style={{ color: 'var(--text-secondary)', fontSize: '1rem', lineHeight: 1.7, marginBottom: '20px', maxWidth: '600px' }}>{filtered[0].excerpt}</p>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                      <span style={{ color: 'var(--accent-primary)', fontSize: '0.75rem', fontFamily: 'Orbitron, monospace' }}>{filtered[0].category}</span>
                      <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>{new Date(filtered[0].createdAt).toLocaleDateString()}</span>
                      <span style={{ color: 'var(--accent-primary)', marginLeft: 'auto', fontFamily: 'Orbitron, monospace', fontSize: '0.8rem' }}>Read More →</span>
                    </div>
                  </div>
                </Link>
              </div>

              {/* Grid */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '20px' }}>
                {filtered.slice(1).map(n => (
                  <Link key={n._id} href={`/news/${n.slug || n._id}`} style={{ textDecoration: 'none' }}>
                    <div className="news-card" style={{ padding: '24px', height: '100%', display: 'flex', flexDirection: 'column' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
                        <span style={{ fontSize: '1.8rem' }}>{catEmoji[n.category] || '📰'}</span>
                        <span style={{ fontSize: '0.7rem', color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', letterSpacing: '0.1em' }}>{n.category}</span>
                      </div>
                      <h3 style={{ color: 'var(--text-primary)', fontFamily: 'Orbitron, monospace', fontWeight: 600, fontSize: '0.95rem', lineHeight: 1.4, marginBottom: '10px', flex: 1 }}>{n.title}</h3>
                      <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', lineHeight: 1.6, marginBottom: '16px' }}>{n.excerpt?.substring(0, 120)}...</p>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>{new Date(n.createdAt).toLocaleDateString()}</span>
                        <span style={{ color: 'var(--accent-primary)', fontSize: '0.8rem', fontFamily: 'Orbitron, monospace' }}>Read →</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </Layout>
  );
}
