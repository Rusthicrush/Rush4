import { useState, useEffect } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';
import CommentsSection from '../../components/CommentsSection';
import { useRouter } from 'next/router';

export default function NewsDetail() {
  const router = useRouter();
  const { slug } = router.query;
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    fetch(`/api/news/${slug}`)
      .then(r => r.json())
      .then(d => { setArticle(d.news); setLoading(false); })
      .catch(() => {
        setArticle({
          _id: slug,
          slug,
          title: 'Article Not Found',
          content: 'This article may have been moved or deleted.',
          category: 'Gaming',
          createdAt: new Date().toISOString(),
          excerpt: '',
        });
        setLoading(false);
      });
  }, [slug]);

  if (loading) {
    return (
      <Layout title="Loading...">
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
          <div className="loading-spinner" />
        </div>
      </Layout>
    );
  }

  if (!article) return null;

  return (
    <Layout title={article.title} description={article.excerpt}>
      <div style={{ padding: '60px 0 80px', position: 'relative', zIndex: 1 }}>
        <div style={{ maxWidth: '800px', margin: '0 auto', padding: '0 20px' }}>
          {/* Breadcrumb */}
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '30px' }}>
            <Link href="/" style={{ color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.85rem' }}>Home</Link>
            <span style={{ color: 'var(--border-color)' }}>›</span>
            <Link href="/news" style={{ color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.85rem' }}>News</Link>
            <span style={{ color: 'var(--border-color)' }}>›</span>
            <span style={{ color: 'var(--accent-primary)', fontSize: '0.85rem' }}>{article.category}</span>
          </div>

          {/* Article Header */}
          <div style={{ marginBottom: '40px' }}>
            <span style={{ fontSize: '0.7rem', color: 'var(--accent-primary)', fontFamily: 'Orbitron, monospace', letterSpacing: '0.15em', display: 'inline-block', marginBottom: '16px', background: 'rgba(0,212,255,0.1)', border: '1px solid var(--border-color)', padding: '4px 12px', borderRadius: '100px' }}>
              {article.category}
            </span>
            <h1 style={{ fontFamily: 'Orbitron, monospace', fontWeight: 700, fontSize: 'clamp(1.4rem, 3vw, 2.2rem)', color: 'var(--text-primary)', lineHeight: 1.3, marginBottom: '16px' }}>
              {article.title}
            </h1>
            <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>By {article.author || 'RUSH Admin'}</span>
              <span style={{ color: 'var(--border-color)' }}>·</span>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>{new Date(article.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
          </div>

          {/* Divider */}
          <div style={{ height: '2px', background: 'linear-gradient(90deg, var(--accent-primary), var(--accent-secondary), transparent)', marginBottom: '40px' }} />

          {/* Content */}
          <div style={{ color: 'var(--text-primary)', fontSize: '1.05rem', lineHeight: 1.8, marginBottom: '60px' }}>
            {article.content?.split('\n').map((para, i) => (
              para.trim() ? <p key={i} style={{ marginBottom: '20px' }}>{para}</p> : <br key={i} />
            ))}
          </div>

          {/* Tags */}
          {article.tags?.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '40px' }}>
              {article.tags.map(tag => (
                <span key={tag} style={{ background: 'rgba(0,212,255,0.08)', border: '1px solid var(--border-color)', color: 'var(--text-secondary)', fontSize: '0.75rem', padding: '4px 12px', borderRadius: '100px', fontFamily: 'Orbitron, monospace' }}>
                  #{tag}
                </span>
              ))}
            </div>
          )}

          <CommentsSection pageSlug={slug} pageName={article.title} />
        </div>
      </div>
    </Layout>
  );
}
