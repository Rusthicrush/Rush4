import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import Layout from '../components/Layout';

export default function Admin() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [tab, setTab] = useState('news');
  const [news, setNews] = useState([]);
  const [comments, setComments] = useState([]);
  const [scores, setScores] = useState([]);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ title: '', excerpt: '', content: '', category: 'Gaming', imageUrl: '', tags: '' });
  const [editing, setEditing] = useState(null);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (status === 'loading') return;
    if (!session) { router.push('/auth/signin'); return; }
    if (!session.user.isAdmin) { router.push('/'); return; }
    fetchAll();
  }, [session, status]);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [nRes, cRes] = await Promise.all([
        fetch('/api/news?limit=50'),
        fetch('/api/comments?limit=50'),
      ]);
      const nData = await nRes.json();
      const cData = await cRes.json();
      setNews(nData.news || []);
      setComments(cData.comments || []);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const saveNews = async () => {
    const method = editing ? 'PUT' : 'POST';
    const url = editing ? `/api/news/${editing}` : '/api/news';
    const body = { ...form, tags: form.tags.split(',').map(t => t.trim()).filter(Boolean) };
    try {
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (res.ok) {
        setMsg('✓ Saved!');
        setForm({ title: '', excerpt: '', content: '', category: 'Gaming', imageUrl: '', tags: '' });
        setEditing(null);
        fetchAll();
      } else {
        const d = await res.json();
        setMsg('⚠️ ' + (d.error || 'Error'));
      }
    } catch (e) { setMsg('⚠️ Error saving'); }
    setTimeout(() => setMsg(''), 3000);
  };

  const deleteNews = async (id) => {
    if (!confirm('Delete this article?')) return;
    await fetch(`/api/news/${id}`, { method: 'DELETE' });
    fetchAll();
  };

  const deleteComment = async (id) => {
    if (!confirm('Delete this comment?')) return;
    await fetch(`/api/comments?id=${id}`, { method: 'DELETE' });
    fetchAll();
  };

  const editNews = (n) => {
    setEditing(n._id);
    setForm({ title: n.title, excerpt: n.excerpt, content: n.content, category: n.category, imageUrl: n.imageUrl || '', tags: n.tags?.join(', ') || '' });
    setTab('create');
    window.scrollTo(0, 0);
  };

  if (status === 'loading') {
    return (
      <Layout title="Admin"><div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
        <div className="loading-spinner" />
      </div></Layout>
    );
  }

  if (!session?.user?.isAdmin) return null;

  const TABS = [
    { id: 'news', label: '📰 News List' },
    { id: 'create', label: editing ? '✏️ Edit News' : '✏️ Create News' },
    { id: 'comments', label: `💬 Comments (${comments.length})` },
  ];

  return (
    <Layout title="Admin Dashboard">
      <div style={{ padding: '40px 0 80px', position: 'relative', zIndex: 1 }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
            <div>
              <h1 style={{ fontFamily: 'Orbitron, monospace', fontWeight: 700, fontSize: '1.8rem', color: '#ffd700', textShadow: '0 0 20px rgba(255,215,0,0.4)', marginBottom: '4px' }}>
                ⚡ ADMIN DASHBOARD
              </h1>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>Logged in as {session.user.email}</p>
            </div>
            <div style={{ display: 'flex', gap: '16px' }}>
              <div className="glass-card" style={{ padding: '12px 20px', textAlign: 'center' }}>
                <p style={{ fontFamily: 'Orbitron, monospace', fontSize: '1.4rem', color: 'var(--accent-primary)', fontWeight: 700 }}>{news.length}</p>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.7rem', letterSpacing: '0.1em' }}>ARTICLES</p>
              </div>
              <div className="glass-card" style={{ padding: '12px 20px', textAlign: 'center' }}>
                <p style={{ fontFamily: 'Orbitron, monospace', fontSize: '1.4rem', color: 'var(--accent-primary)', fontWeight: 700 }}>{comments.length}</p>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.7rem', letterSpacing: '0.1em' }}>COMMENTS</p>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{ display: 'flex', gap: '4px', marginBottom: '30px', borderBottom: '1px solid var(--border-color)' }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                padding: '12px 20px',
                background: 'none', border: 'none',
                borderBottom: `2px solid ${tab === t.id ? 'var(--accent-primary)' : 'transparent'}`,
                color: tab === t.id ? 'var(--accent-primary)' : 'var(--text-secondary)',
                fontFamily: 'Orbitron, monospace', fontSize: '0.75rem', letterSpacing: '0.1em',
                cursor: 'pointer', transition: 'all 0.2s', marginBottom: '-1px',
              }}>
                {t.label}
              </button>
            ))}
          </div>

          {/* News List */}
          {tab === 'news' && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '16px' }}>
                <button onClick={() => setTab('create')} className="neon-btn-solid" style={{ padding: '10px 24px', fontSize: '0.75rem' }}>
                  + New Article
                </button>
              </div>
              {loading ? <div style={{ textAlign: 'center', padding: '60px' }}><div className="loading-spinner" style={{ margin: '0 auto' }} /></div> : (
                news.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-secondary)' }}>
                    <p>No articles yet. Create your first one!</p>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {news.map(n => (
                      <div key={n._id} className="glass-card" style={{ padding: '20px', display: 'flex', alignItems: 'center', gap: '20px', flexWrap: 'wrap' }}>
                        <div style={{ flex: 1, minWidth: '200px' }}>
                          <h3 style={{ color: 'var(--text-primary)', fontWeight: 600, fontSize: '0.95rem', marginBottom: '4px' }}>{n.title}</h3>
                          <div style={{ display: 'flex', gap: '12px' }}>
                            <span style={{ color: 'var(--accent-primary)', fontSize: '0.75rem', fontFamily: 'Orbitron, monospace' }}>{n.category}</span>
                            <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>{new Date(n.createdAt).toLocaleDateString()}</span>
                            <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>👁 {n.views || 0}</span>
                          </div>
                        </div>
                        <div style={{ display: 'flex', gap: '8px' }}>
                          <button onClick={() => editNews(n)} className="neon-btn" style={{ padding: '6px 16px', fontSize: '0.7rem' }}>Edit</button>
                          <button onClick={() => deleteNews(n._id)} style={{ padding: '6px 16px', fontSize: '0.7rem', fontFamily: 'Orbitron, monospace', border: '1px solid #ff3200', color: '#ff3200', background: 'transparent', cursor: 'pointer', borderRadius: '4px', letterSpacing: '0.1em' }}>Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                )
              )}
            </div>
          )}

          {/* Create/Edit News */}
          {tab === 'create' && (
            <div className="glass-card" style={{ padding: '32px' }}>
              <h2 style={{ fontFamily: 'Orbitron, monospace', fontSize: '1rem', color: 'var(--accent-primary)', marginBottom: '24px', letterSpacing: '0.15em' }}>
                {editing ? 'EDIT ARTICLE' : 'CREATE ARTICLE'}
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div>
                  <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: '0.75rem', fontFamily: 'Orbitron, monospace', letterSpacing: '0.15em', marginBottom: '6px' }}>TITLE *</label>
                  <input className="rush-input" value={form.title} onChange={e => setForm({...form, title: e.target.value})} placeholder="Article title..." maxLength={200} />
                </div>
                <div>
                  <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: '0.75rem', fontFamily: 'Orbitron, monospace', letterSpacing: '0.15em', marginBottom: '6px' }}>EXCERPT *</label>
                  <textarea className="rush-input" value={form.excerpt} onChange={e => setForm({...form, excerpt: e.target.value})} placeholder="Short description..." rows={2} maxLength={500} style={{ resize: 'vertical' }} />
                </div>
                <div>
                  <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: '0.75rem', fontFamily: 'Orbitron, monospace', letterSpacing: '0.15em', marginBottom: '6px' }}>CONTENT *</label>
                  <textarea className="rush-input" value={form.content} onChange={e => setForm({...form, content: e.target.value})} placeholder="Full article content..." rows={8} style={{ resize: 'vertical', minHeight: '200px' }} />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: '0.75rem', fontFamily: 'Orbitron, monospace', letterSpacing: '0.15em', marginBottom: '6px' }}>CATEGORY</label>
                    <select className="rush-input" value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
                      {['Gaming','Esports','Updates','Reviews','Community'].map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: '0.75rem', fontFamily: 'Orbitron, monospace', letterSpacing: '0.15em', marginBottom: '6px' }}>IMAGE URL</label>
                    <input className="rush-input" value={form.imageUrl} onChange={e => setForm({...form, imageUrl: e.target.value})} placeholder="https://..." />
                  </div>
                </div>
                <div>
                  <label style={{ display: 'block', color: 'var(--text-secondary)', fontSize: '0.75rem', fontFamily: 'Orbitron, monospace', letterSpacing: '0.15em', marginBottom: '6px' }}>TAGS (comma separated)</label>
                  <input className="rush-input" value={form.tags} onChange={e => setForm({...form, tags: e.target.value})} placeholder="gaming, esports, update..." />
                </div>
                {msg && <p style={{ color: msg.startsWith('✓') ? '#00ff88' : '#ff3200', fontFamily: 'Orbitron, monospace', fontSize: '0.85rem' }}>{msg}</p>}
                <div style={{ display: 'flex', gap: '12px' }}>
                  <button onClick={saveNews} className="neon-btn-solid" style={{ padding: '12px 32px', fontSize: '0.8rem' }}>
                    {editing ? 'Update Article' : 'Publish Article'}
                  </button>
                  {editing && (
                    <button onClick={() => { setEditing(null); setForm({ title: '', excerpt: '', content: '', category: 'Gaming', imageUrl: '', tags: '' }); }} className="neon-btn" style={{ padding: '12px 24px', fontSize: '0.8rem' }}>
                      Cancel
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Comments Moderation */}
          {tab === 'comments' && (
            <div>
              {loading ? <div style={{ textAlign: 'center', padding: '60px' }}><div className="loading-spinner" style={{ margin: '0 auto' }} /></div> : (
                comments.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-secondary)' }}>No comments yet.</div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {comments.map(c => (
                      <div key={c._id} className="glass-card" style={{ padding: '20px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px', flexWrap: 'wrap', gap: '8px' }}>
                          <div>
                            <p style={{ color: 'var(--text-primary)', fontWeight: 600, fontSize: '0.9rem' }}>{c.commenterName}</p>
                            <p style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>
                              {c.commenterEmail} · via {c.provider} · on "{c.pageName}"
                            </p>
                            <p style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>{new Date(c.createdAt).toLocaleString()}</p>
                          </div>
                          <button onClick={() => deleteComment(c._id)} style={{ padding: '6px 16px', fontSize: '0.7rem', fontFamily: 'Orbitron, monospace', border: '1px solid #ff3200', color: '#ff3200', background: 'transparent', cursor: 'pointer', borderRadius: '4px', letterSpacing: '0.1em', whiteSpace: 'nowrap' }}>
                            🗑 Delete
                          </button>
                        </div>
                        <p style={{ color: 'var(--text-primary)', fontSize: '0.9rem', lineHeight: 1.6 }}>{c.comment}</p>
                      </div>
                    ))}
                  </div>
                )
              )}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
