/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
    './games/**/*.{js,ts,jsx,tsx}',
    './admin/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        galaxy: {
          50:  '#e8f4ff',
          100: '#d0e9ff',
          200: '#a0d2ff',
          300: '#60b8ff',
          400: '#1a95ff',
          500: '#0070e0',
          600: '#0055b8',
          700: '#003d8a',
          800: '#002560',
          900: '#000f35',
          950: '#00061a',
        },
        neon: {
          blue: '#00d4ff',
          cyan: '#00ffff',
          purple: '#8b5cf6',
          pink: '#ff006e',
        }
      },
      fontFamily: {
        display: ['Orbitron', 'monospace'],
        body: ['Exo 2', 'sans-serif'],
        mono: ['Share Tech Mono', 'monospace'],
      },
      animation: {
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'scan': 'scan 3s linear infinite',
        'particle': 'particle 8s linear infinite',
        'flicker': 'flicker 3s ease-in-out infinite',
        'slide-up': 'slideUp 0.5s ease-out',
        'slide-down': 'slideDown 0.3s ease-out',
        'fade-in': 'fadeIn 0.6s ease-out',
        'shimmer': 'shimmer 2s linear infinite',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 20px #00d4ff, 0 0 40px #0070e0' },
          '50%': { boxShadow: '0 0 40px #00d4ff, 0 0 80px #0070e0, 0 0 120px #003d8a' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        scan: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        flicker: {
          '0%, 100%': { opacity: '1' },
          '92%': { opacity: '1' },
          '93%': { opacity: '0.4' },
          '94%': { opacity: '1' },
          '96%': { opacity: '0.7' },
          '97%': { opacity: '1' },
        },
      },
      backgroundImage: {
        'galaxy-gradient': 'radial-gradient(ellipse at center, #001a4d 0%, #000a1f 50%, #000510 100%)',
        'neon-gradient': 'linear-gradient(135deg, #00d4ff 0%, #0070e0 50%, #8b5cf6 100%)',
        'glass': 'linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%)',
      },
      backdropBlur: {
        xs: '2px',
      },
      boxShadow: {
        'neon-blue': '0 0 20px #00d4ff, 0 0 40px rgba(0, 112, 224, 0.5)',
        'neon-cyan': '0 0 20px #00ffff, 0 0 40px rgba(0, 255, 255, 0.3)',
        'neon-purple': '0 0 20px #8b5cf6, 0 0 40px rgba(139, 92, 246, 0.3)',
        'glass': '0 8px 32px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255,255,255,0.05)',
      },
    },
  },
  plugins: [],
}
