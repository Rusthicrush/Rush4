import Head from 'next/head';
import Navbar from './Navbar';
import Footer from './Footer';
import ParticleBackground from './ParticleBackground';

export default function Layout({ children, title = 'RUSH Gaming', description = 'Your ultimate galaxy gaming destination' }) {
  return (
    <>
      <Head>
        <title>{title} | RUSH Gaming</title>
        <meta name="description" content={description} />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;800;900&family=Exo+2:wght@300;400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet" />
      </Head>
      <div className="scanline" style={{ position: 'relative', minHeight: '100vh' }}>
        <ParticleBackground />
        <div className="grid-pattern" style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none' }} />
        <div style={{ position: 'relative', zIndex: 10 }}>
          <Navbar />
          <main style={{ paddingTop: '64px', minHeight: 'calc(100vh - 64px)' }}>
            {children}
          </main>
          <Footer />
        </div>
      </div>
    </>
  );
}
