import { useState, useEffect } from 'react';
import { useSession, signIn } from 'next-auth/react';

export default function CommentsSection({ pageSlug, pageName }) {
  const { data: session } = useSession();
  const [comments, setComments] = useState([]);
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchComments();
  }, [pageSlug]);

  const fetchComments = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/comments?pageSlug=${pageSlug}&limit=20`);
      const data = await res.json();
      setComments(data.comments || []);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;
    setSubmitting(true);
    setError('');
    setSuccess('');

    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comment: comment.trim(), pageName, pageSlug }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to post comment');
      setComment('');
      setSuccess('Comment posted!');
      fetchComments();
    } catch (e) {
      setError(e.message);
    }
    setSubmitting(false);
  };

  return (
    <div style={{ marginTop: '60px' }}>
      <h3 className="section-header" style={{ marginBottom: '30px' }}>Comments</h3>

      {/* Post Comment */}
      <div className="glass-card" style={{ padding: '24px', marginBottom: '30px' }}>
        {session ? (
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
              {session.user.image && (
                <img src={session.user.image} alt={session.user.name} style={{ width: '36px', height: '36px', borderRadius: '50%', border: '2px solid var(--accent-primary)' }} />
              )}
              <div>
                <p style={{ color: 'var(--text-primary)', fontWeight: 600, fontSize: '0.9rem' }}>{session.user.name}</p>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>via {session.user.provider || 'Google'}</p>
              </div>
            </div>
            <textarea
              className="rush-input"
              placeholder="Share your thoughts..."
              value={comment}
              onChange={e => setComment(e.target.value)}
              rows={3}
              maxLength={1000}
              style={{ resize: 'vertical', minHeight: '80px' }}
              required
            />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '12px' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>{comment.length}/1000</span>
              <button type="submit" className="neon-btn-solid" disabled={submitting} style={{ padding: '10px 24px', fontSize: '0.75rem' }}>
                {submitting ? 'Posting...' : 'Post Comment'}
              </button>
            </div>
            {error && <p style={{ color: '#ff3200', fontSize: '0.85rem', marginTop: '8px' }}>⚠️ {error}</p>}
            {success && <p style={{ color: '#00ff88', fontSize: '0.85rem', marginTop: '8px' }}>✓ {success}</p>}
          </form>
        ) : (
          <div style={{ textAlign: 'center', padding: '20px' }}>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '16px' }}>Sign in to join the conversation</p>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '12px', flexWrap: 'wrap' }}>
              <button onClick={() => signIn('google')} className="neon-btn-solid" style={{ padding: '10px 24px', fontSize: '0.75rem' }}>
                🔴 Sign in with Google
              </button>
              <button onClick={() => signIn('facebook')} className="neon-btn" style={{ padding: '10px 24px', fontSize: '0.75rem' }}>
                🔵 Sign in with Facebook
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Comments List */}
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '40px' }}>
          <div className="loading-spinner" />
        </div>
      ) : comments.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text-secondary)' }}>
          <p style={{ fontSize: '2rem', marginBottom: '8px' }}>💬</p>
          <p>No comments yet. Be the first!</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {comments.map(c => (
            <div key={c._id} className="glass-card" style={{ padding: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px', flexWrap: 'wrap', gap: '8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{
                    width: '36px', height: '36px', borderRadius: '50%',
                    background: `linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontFamily: 'Orbitron, monospace', fontWeight: 700, fontSize: '0.9rem', color: 'var(--bg-primary)',
                  }}>
                    {c.commenterName?.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p style={{ color: 'var(--text-primary)', fontWeight: 600, fontSize: '0.9rem' }}>{c.commenterName}</p>
                    <p style={{ color: 'var(--text-secondary)', fontSize: '0.7rem' }}>
                      via {c.provider} · {new Date(c.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                {session?.user?.isAdmin && (
                  <button
                    onClick={async () => {
                      if (confirm('Delete this comment?')) {
                        await fetch(`/api/comments?id=${c._id}`, { method: 'DELETE' });
                        fetchComments();
                      }
                    }}
                    style={{ background: 'none', border: 'none', color: '#ff3200', cursor: 'pointer', fontSize: '0.8rem' }}
                  >
                    🗑 Delete
                  </button>
                )}
              </div>
              <p style={{ color: 'var(--text-primary)', lineHeight: 1.6, fontSize: '0.95rem' }}>{c.comment}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
