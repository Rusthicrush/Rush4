import { useState, useEffect } from 'react';

const themes = [
  { id: 'galaxy-blue', label: 'Galaxy Blue', color: '#00d4ff' },
  { id: 'neon-dark', label: 'Neon Dark', color: '#b400ff' },
  { id: 'cyber-purple', label: 'Cyber Purple', color: '#8b5cf6' },
  { id: 'ice-blue', label: 'Ice Blue', color: '#64dcff' },
  { id: 'red-inferno', label: 'Red Inferno', color: '#ff3200' },
];

export default function ThemeSwitcher({ expanded = false }) {
  const [activeTheme, setActiveTheme] = useState('galaxy-blue');
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('rush-theme') || 'galaxy-blue';
    setActiveTheme(saved);
    applyTheme(saved);
  }, []);

  const applyTheme = (themeId) => {
    const root = document.documentElement;
    if (themeId === 'galaxy-blue') {
      root.removeAttribute('data-theme');
    } else {
      root.setAttribute('data-theme', themeId);
    }
  };

  const handleTheme = (themeId) => {
    setActiveTheme(themeId);
    localStorage.setItem('rush-theme', themeId);
    applyTheme(themeId);
    setOpen(false);
  };

  if (expanded) {
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
        {themes.map(t => (
          <button
            key={t.id}
            onClick={() => handleTheme(t.id)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              padding: '10px 16px',
              background: activeTheme === t.id ? 'rgba(255,255,255,0.05)' : 'transparent',
              border: `1px solid ${activeTheme === t.id ? t.color : 'var(--border-color)'}`,
              borderRadius: '8px',
              cursor: 'pointer',
              color: activeTheme === t.id ? t.color : 'var(--text-secondary)',
              fontFamily: 'Orbitron, monospace',
              fontSize: '0.75rem',
              letterSpacing: '0.1em',
              transition: 'all 0.3s ease',
              boxShadow: activeTheme === t.id ? `0 0 10px ${t.color}40` : 'none',
            }}
          >
            <span style={{ width: '12px', height: '12px', borderRadius: '50%', background: t.color, boxShadow: `0 0 6px ${t.color}` }} />
            {t.label}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          width: '28px', height: '28px',
          borderRadius: '50%',
          background: themes.find(t => t.id === activeTheme)?.color,
          border: '2px solid white',
          cursor: 'pointer',
          boxShadow: `0 0 10px ${themes.find(t => t.id === activeTheme)?.color}`,
          transition: 'transform 0.3s ease',
          transform: open ? 'scale(1.2)' : 'scale(1)',
        }}
        title="Switch theme"
      />
      {open && (
        <div style={{
          position: 'absolute',
          top: '40px',
          right: '0',
          background: 'rgba(0, 6, 26, 0.98)',
          border: '1px solid var(--border-color)',
          borderRadius: '12px',
          padding: '16px',
          display: 'flex',
          flexDirection: 'column',
          gap: '10px',
          zIndex: 100,
          minWidth: '180px',
          backdropFilter: 'blur(20px)',
        }}>
          <p style={{ fontFamily: 'Orbitron, monospace', fontSize: '0.65rem', color: 'var(--text-secondary)', letterSpacing: '0.15em', marginBottom: '4px' }}>
            THEME
          </p>
          {themes.map(t => (
            <button
              key={t.id}
              onClick={() => handleTheme(t.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                color: activeTheme === t.id ? t.color : 'var(--text-secondary)',
                fontFamily: 'Exo 2, sans-serif',
                fontSize: '0.85rem',
                padding: '4px 0',
                transition: 'color 0.2s',
                fontWeight: activeTheme === t.id ? '600' : '400',
              }}
            >
              <span style={{ width: '14px', height: '14px', borderRadius: '50%', background: t.color, boxShadow: `0 0 6px ${t.color}`, flexShrink: 0 }} />
              {t.label}
              {activeTheme === t.id && <span style={{ marginLeft: 'auto', fontSize: '0.75rem' }}>✓</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
