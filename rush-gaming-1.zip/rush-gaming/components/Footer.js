import Link from 'next/link';

export default function Footer() {
  return (
    <footer style={{
      background: 'rgba(0, 3, 15, 0.95)',
      borderTop: '1px solid var(--border-color)',
      padding: '60px 0 30px',
      position: 'relative',
      zIndex: 10,
    }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '40px', marginBottom: '50px' }}>
          {/* Brand */}
          <div>
            <h3 style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900, fontSize: '2rem', color: 'var(--accent-primary)', textShadow: '0 0 20px var(--accent-primary)', marginBottom: '12px' }}>
              RUSH
            </h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', lineHeight: 1.6, maxWidth: '240px' }}>
              Your ultimate galaxy gaming destination. Play, compete, and dominate.
            </p>
            {/* Social Icons */}
            <div style={{ display: 'flex', gap: '12px', marginTop: '20px' }}>
              {['𝕏', '📘', '📸', '💬', '🎮'].map((icon, i) => (
                <button key={i} style={{
                  width: '36px', height: '36px',
                  borderRadius: '8px',
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  color: 'var(--text-secondary)',
                  fontSize: '1rem',
                  cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'all 0.3s ease',
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent-primary)'; e.currentTarget.style.color = 'var(--accent-primary)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border-color)'; e.currentTarget.style.color = 'var(--text-secondary)'; }}
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>

          {/* Games */}
          <div>
            <h4 style={{ fontFamily: 'Orbitron, monospace', fontSize: '0.8rem', letterSpacing: '0.2em', color: 'var(--accent-primary)', marginBottom: '16px', textTransform: 'uppercase' }}>
              Games
            </h4>
            {['Space Battle', 'Snake Game', 'Car Racing', 'Chess', 'Puzzle Blast'].map(g => (
              <Link key={g} href={`/games/${g.toLowerCase().replace(/\s+/g, '-')}`}
                style={{ display: 'block', color: 'var(--text-secondary)', fontSize: '0.9rem', padding: '4px 0', textDecoration: 'none', transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = 'var(--accent-primary)'}
                onMouseLeave={e => e.target.style.color = 'var(--text-secondary)'}
              >{g}</Link>
            ))}
          </div>

          {/* Explore */}
          <div>
            <h4 style={{ fontFamily: 'Orbitron, monospace', fontSize: '0.8rem', letterSpacing: '0.2em', color: 'var(--accent-primary)', marginBottom: '16px', textTransform: 'uppercase' }}>
              Explore
            </h4>
            {[{ label: 'Latest News', href: '/news' }, { label: 'Leaderboard', href: '/leaderboard' }, { label: 'All Games', href: '/games' }, { label: 'Profile', href: '/profile' }].map(l => (
              <Link key={l.href} href={l.href}
                style={{ display: 'block', color: 'var(--text-secondary)', fontSize: '0.9rem', padding: '4px 0', textDecoration: 'none', transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = 'var(--accent-primary)'}
                onMouseLeave={e => e.target.style.color = 'var(--text-secondary)'}
              >{l.label}</Link>
            ))}
          </div>

          {/* Status */}
          <div>
            <h4 style={{ fontFamily: 'Orbitron, monospace', fontSize: '0.8rem', letterSpacing: '0.2em', color: 'var(--accent-primary)', marginBottom: '16px', textTransform: 'uppercase' }}>
              System Status
            </h4>
            {[
              { label: 'Game Servers', ok: true },
              { label: 'Auth Service', ok: true },
              { label: 'News Feed', ok: true },
            ].map(s => (
              <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '4px 0' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: s.ok ? '#00ff88' : '#ff3200', boxShadow: `0 0 6px ${s.ok ? '#00ff88' : '#ff3200'}` }} />
                <span style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom */}
        <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '24px', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', fontFamily: 'Share Tech Mono, monospace' }}>
            © {new Date().getFullYear()} RUSH GAMING. ALL RIGHTS RESERVED.
          </p>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.75rem', fontFamily: 'Share Tech Mono, monospace' }}>
            BUILT FOR CHAMPIONS. DESIGNED FOR THE FUTURE.
          </p>
        </div>
      </div>
    </footer>
  );
}
