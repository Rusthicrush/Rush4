import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSession, signIn, signOut } from 'next-auth/react';
import { useRouter } from 'next/router';
import ThemeSwitcher from './ThemeSwitcher';

const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'Games', href: '/games' },
  { label: 'News', href: '/news' },
  { label: 'Leaderboard', href: '/leaderboard' },
];

export default function Navbar() {
  const { data: session } = useSession();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const router = useRouter();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/games?search=${encodeURIComponent(searchQuery)}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <nav className={`navbar fixed top-0 left-0 right-0 z-50 ${scrolled ? 'scrolled' : ''}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <span style={{
              fontFamily: 'Orbitron, monospace',
              fontWeight: 900,
              fontSize: '1.8rem',
              color: 'var(--accent-primary)',
              textShadow: '0 0 10px var(--accent-primary), 0 0 20px var(--accent-secondary)',
              letterSpacing: '0.1em',
            }}>RUSH</span>
            <span style={{
              fontSize: '0.6rem',
              color: 'var(--text-secondary)',
              fontFamily: 'Orbitron, monospace',
              letterSpacing: '0.2em',
              marginTop: '2px',
            }}>GAMING</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                style={{
                  fontFamily: 'Orbitron, monospace',
                  fontSize: '0.75rem',
                  letterSpacing: '0.15em',
                  textTransform: 'uppercase',
                  color: router.pathname === link.href ? 'var(--accent-primary)' : 'var(--text-secondary)',
                  textDecoration: 'none',
                  transition: 'color 0.3s ease',
                  textShadow: router.pathname === link.href ? '0 0 10px var(--accent-primary)' : 'none',
                }}
                onMouseEnter={e => e.target.style.color = 'var(--accent-primary)'}
                onMouseLeave={e => e.target.style.color = router.pathname === link.href ? 'var(--accent-primary)' : 'var(--text-secondary)'}
              >
                {link.label}
              </Link>
            ))}
            {session?.user?.isAdmin && (
              <Link
                href="/admin"
                style={{
                  fontFamily: 'Orbitron, monospace',
                  fontSize: '0.75rem',
                  letterSpacing: '0.15em',
                  textTransform: 'uppercase',
                  color: '#ffd700',
                  textDecoration: 'none',
                  textShadow: '0 0 10px rgba(255,215,0,0.5)',
                }}
              >
                ⚡ Admin
              </Link>
            )}
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-4">
            {/* Search */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-secondary)', fontSize: '1.1rem', padding: '4px' }}
              aria-label="Search"
            >
              🔍
            </button>

            <ThemeSwitcher />

            {session ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                  {session.user.name?.split(' ')[0]}
                </span>
                <button
                  onClick={() => signOut()}
                  className="neon-btn"
                  style={{ padding: '6px 16px', fontSize: '0.7rem' }}
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <button
                onClick={() => signIn()}
                className="neon-btn-solid"
                style={{ padding: '8px 20px', fontSize: '0.7rem' }}
              >
                Sign In
              </button>
            )}

            {/* Mobile menu button */}
            <button
              className="md:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--accent-primary)', fontSize: '1.4rem' }}
            >
              {mobileOpen ? '✕' : '☰'}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div style={{ padding: '8px 0 12px', borderTop: '1px solid var(--border-color)' }}>
            <form onSubmit={handleSearch} style={{ display: 'flex', gap: '8px' }}>
              <input
                className="rush-input"
                type="text"
                placeholder="Search games..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                autoFocus
                style={{ flex: 1 }}
              />
              <button type="submit" className="neon-btn-solid" style={{ padding: '10px 20px', fontSize: '0.75rem' }}>
                Search
              </button>
            </form>
          </div>
        )}

        {/* Mobile Menu */}
        {mobileOpen && (
          <div style={{
            background: 'rgba(0, 6, 26, 0.98)',
            border: '1px solid var(--border-color)',
            borderRadius: '12px',
            padding: '20px',
            marginBottom: '10px',
          }}>
            {navLinks.map(link => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                style={{
                  display: 'block',
                  padding: '12px 0',
                  fontFamily: 'Orbitron, monospace',
                  fontSize: '0.85rem',
                  letterSpacing: '0.15em',
                  color: router.pathname === link.href ? 'var(--accent-primary)' : 'var(--text-secondary)',
                  textDecoration: 'none',
                  borderBottom: '1px solid var(--border-color)',
                }}
              >
                {link.label}
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
